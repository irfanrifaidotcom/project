<?php
require_once 'config.php';
if(!empty($_SESSION['user'])) redirect('index.php');
$error='';
if($_SERVER['REQUEST_METHOD']==='POST') { csrf_check(); $username=trim($_POST['username']??''); $password=$_POST['password']??''; $s=$pdo->prepare('SELECT id,name,username,password,role,is_active FROM users WHERE username=? LIMIT 1'); $s->execute([$username]); $u=$s->fetch(); if($u && $u['is_active'] && password_verify($password,$u['password'])) { session_regenerate_id(true); unset($u['password'],$u['is_active']); $_SESSION['user']=$u; log_activity($pdo,'LOGIN','Login berhasil'); redirect('index.php'); } $error='Username atau password salah, atau akun dinonaktifkan.'; }
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color" content="#18b7c9">
  <title>Login | SIDARA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/admin-lte@4.0.0-rc5/dist/css/adminlte.min.css" rel="stylesheet">
  <script>window.tailwind = window.tailwind || {}; window.tailwind.config = { prefix: 'tw-', corePlugins: { preflight: false } };</script>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="<?=e(app_url('assets/style.css?v='.(is_file(__DIR__.'/assets/style.css') ? filemtime(__DIR__.'/assets/style.css') : time())))?>" rel="stylesheet">
</head>
<body class="login-page">
<div class="container"><div class="row justify-content-center align-items-center min-vh-100 py-4"><div class="col-sm-10 col-md-7 col-lg-5 col-xl-4">
  <div class="card border-0 shadow-lg login-card"><div class="card-body p-4 p-lg-5">
    <div class="brand-mark-login mb-4"><i class="bi bi-car-front-fill"></i></div>
    <div class="text-uppercase small fw-bold mb-2 tw-inline-flex tw-items-center tw-gap-2 tw-rounded-full tw-bg-sky-50 tw-px-3 tw-py-2" style="letter-spacing:1.2px;color:#168ab8"><span class="tw-h-2 tw-w-2 tw-rounded-full tw-bg-cyan-500"></span>Sistem Operasional Armada</div>
    <h2 class="fw-bold mb-1" style="color:#18394e">SIDARA</h2>
    <p class="text-secondary mb-4">Sistem Informasi Dinas dan Kendaraan</p>
    <?php if($error): ?><div class="alert alert-danger py-2"><?=e($error)?></div><?php endif; ?>
    <form method="post">
      <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
      <div class="mb-3"><label class="form-label">Username</label><div class="input-group"><span class="input-group-text bg-light border-end-0"><i class="bi bi-person text-secondary"></i></span><input class="form-control border-start-0" name="username" required autofocus autocomplete="username" placeholder="Masukkan username"></div></div>
      <div class="mb-4"><label class="form-label">Password</label><div class="input-group"><span class="input-group-text bg-light border-end-0"><i class="bi bi-lock text-secondary"></i></span><input type="password" class="form-control border-start-0" name="password" required autocomplete="current-password" placeholder="Masukkan password"></div></div>
      <button class="btn btn-primary btn-lg w-100"><i class="bi bi-box-arrow-in-right me-2"></i>Masuk ke aplikasi</button>
    </form>
    <div class="small text-secondary mt-4 p-3 rounded-3" style="background:#f3f9fc"><i class="bi bi-info-circle me-1"></i>Akun awal setelah import SQL: <b>admin / password</b>. Segera ubah password setelah login.</div>
  </div></div>
  <div class="text-center small text-secondary mt-3">© <?=date('Y')?> SIDARA · <a href="https://scmedia.web.id/irfan/" target="_blank" rel="noopener noreferrer" class="text-decoration-none fw-semibold">SC Media · Irfan</a></div>
</div></div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@4.0.0-rc5/dist/js/adminlte.min.js"></script>
<script src="<?=e(app_url('assets/app.js?v='.(is_file(__DIR__.'/assets/app.js') ? filemtime(__DIR__.'/assets/app.js') : time())))?>"></script>
</body></html>
