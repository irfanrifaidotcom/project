/* SIDARA UI interactions: sidebar fallback, confirmations, file name previews. */
(function () {
  'use strict';
  const body = document.body;
  const sidebar = document.querySelector('.app-sidebar');
  const backdrop = document.querySelector('[data-sidebar-backdrop]');
  const toggles = document.querySelectorAll('[data-lte-toggle="sidebar"], [data-sidebar-toggle]');

  function isMobile() { return window.matchMedia('(max-width: 991.98px)').matches; }
  function openSidebar() {
    if (!sidebar) return;
    if (isMobile()) body.classList.add('sidebar-open');
    else body.classList.remove('sidebar-collapse');
    if (backdrop) backdrop.classList.toggle('show', isMobile());
  }
  function closeSidebar() {
    body.classList.remove('sidebar-open');
    if (backdrop) backdrop.classList.remove('show');
  }
  toggles.forEach(function (toggle) {
    toggle.addEventListener('click', function (event) {
      event.preventDefault();
      if (isMobile()) {
        if (body.classList.contains('sidebar-open')) closeSidebar(); else openSidebar();
      } else {
        body.classList.toggle('sidebar-collapse');
      }
    });
  });
  if (backdrop) backdrop.addEventListener('click', closeSidebar);
  if (sidebar) sidebar.querySelectorAll('a.nav-link').forEach(function (link) {
    link.addEventListener('click', function () { if (isMobile()) closeSidebar(); });
  });
  document.addEventListener('keydown', function (event) { if (event.key === 'Escape') closeSidebar(); });
  window.addEventListener('resize', function () {
    if (!isMobile()) closeSidebar();
    if (backdrop && !isMobile()) backdrop.classList.remove('show');
  });

  document.querySelectorAll('[data-confirm]').forEach(function (el) {
    el.addEventListener('click', function (event) {
      if (!window.confirm(el.getAttribute('data-confirm') || 'Lanjutkan tindakan ini?')) event.preventDefault();
    });
  });
  document.querySelectorAll('input[type="file"]').forEach(function (input) {
    input.addEventListener('change', function () {
      const label = input.parentElement && input.parentElement.querySelector('[data-file-name]');
      if (label) label.textContent = input.files && input.files[0] ? input.files[0].name : 'Belum ada file dipilih';
    });
  });
})();
