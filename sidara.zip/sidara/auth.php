<?php
require_once __DIR__.'/config.php';
function current_user(){ return $_SESSION['user'] ?? null; }
function require_login(){ if(!current_user()) redirect('login.php'); }
function require_role($roles){ require_login(); $roles=(array)$roles; if(!in_array(current_user()['role'],$roles,true)){ http_response_code(403); die('Akses ditolak. Anda tidak memiliki hak untuk membuka halaman ini.'); } }
