<?php
// Konfigurasi aplikasi Perjalanan Dinas Driver
if (session_status() === PHP_SESSION_NONE) session_start();
date_default_timezone_set('Asia/Jakarta');
$db_host = '127.0.0.1'; $db_name = 'perjalanan_dinas'; $db_user = 'root'; $db_pass = '';
try { $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch (PDOException $e) { http_response_code(500); die('Koneksi database gagal. Pastikan database perjalanan_dinas sudah di-import melalui phpMyAdmin.'); }
function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
/**
 * Build URLs from the application root. By default the app detects its folder
 * (for example /sidara); SIDARA_BASE_PATH may override it, e.g. /sidara/.
 * Use root-relative paths so assets work on every module and after redirects.
 */
function app_url($path = '') {
    static $base = null;
    if ($base === null) {
        $override = getenv('SIDARA_BASE_PATH');
        if ($override !== false && trim($override) !== '') {
            $base = '/' . trim(str_replace('\\', '/', $override), '/') . '/';
        } else {
            $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/sidara/index.php');
            $dir = dirname($script);
            $base = ($dir === '.' || $dir === '/' || $dir === '\\') ? '/' : '/' . trim($dir, '/') . '/';
        }
    }
    $path = ltrim((string)$path, '/');
    return $base . $path;
}
function rupiah($v){ return 'Rp '.number_format((float)$v,0,',','.'); }
function redirect($url){ header('Location: '.$url); exit; }
function csrf_token(){ if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_check(){ if($_SERVER['REQUEST_METHOD']==='POST' && !hash_equals($_SESSION['csrf']??'', $_POST['csrf']??'')){ http_response_code(419); die('Token keamanan tidak valid. Muat ulang halaman dan coba lagi.'); } }


/** Activity logging is available to every entry point, including login.php. */
if (!function_exists('log_activity')) {
    function log_activity($pdo, $action, $detail = '') {
        if (empty($_SESSION['user']['id'])) return;
        try {
            $stmt = $pdo->prepare('INSERT INTO activity_logs (user_id, action, detail, ip_address) VALUES (?, ?, ?, ?)');
            $stmt->execute([$_SESSION['user']['id'], $action, $detail, substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45)]);
        } catch (Throwable $e) {
            // Logging should never prevent a valid login or operation from completing.
            error_log('SIDARA activity log failed: ' . $e->getMessage());
        }
    }
}
