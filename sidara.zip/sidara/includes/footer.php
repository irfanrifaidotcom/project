    </div></div>
  </main>
  <footer class="app-footer">
    <div class="float-end d-none d-sm-inline">Sky Blue Modern</div>
    <strong>© <?=date('Y')?> SIDARA.</strong> Sistem Informasi Dinas dan Kendaraan.
    <span class="footer-credit">Dikembangkan oleh <a href="https://scmedia.web.id/irfan/" target="_blank" rel="noopener noreferrer">SC Media · Irfan</a></span>
  </footer>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@4.0.0-rc5/dist/js/adminlte.min.js"></script>
<script src="<?=e(app_url('assets/app.js?v='.(is_file(__DIR__.'/../assets/app.js') ? filemtime(__DIR__.'/../assets/app.js') : time())))?>"></script>
</body>
</html>
