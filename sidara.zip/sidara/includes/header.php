<?php
require_once __DIR__.'/../auth.php';
require_login();
$me = current_user();
$page_title = $page_title ?? 'Dashboard';
$current = basename($_SERVER['PHP_SELF'] ?? 'index.php');
function menu_active(array $files): string { return in_array(basename($_SERVER['PHP_SELF'] ?? ''), $files, true) ? 'active' : ''; }
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#18b7c9">
  <title><?=e($page_title)?> | SIDARA</title>
  <!-- Bootstrap 5 latest stable CDN; AdminLTE 4 uses Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/admin-lte@4.0.0-rc5/dist/css/adminlte.min.css" rel="stylesheet">
  <script>window.tailwind = window.tailwind || {}; window.tailwind.config = { prefix: 'tw-', corePlugins: { preflight: false } };</script>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="<?=e(app_url('assets/style.css?v='.(is_file(__DIR__.'/../assets/style.css') ? filemtime(__DIR__.'/../assets/style.css') : time())))?>" rel="stylesheet">
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">
  <nav class="app-header navbar navbar-expand bg-white border-bottom">
    <div class="container-fluid">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" data-sidebar-toggle href="#" role="button" aria-label="Buka/tutup menu"><i class="bi bi-list fs-4"></i></a></li>
        <li class="nav-item d-none d-md-block"><span class="nav-link fw-semibold text-secondary">Sistem Informasi Dinas dan Kendaraan</span></li>
      </ul>
      <ul class="navbar-nav ms-auto align-items-center">
        <li class="nav-item me-2 d-none d-sm-block text-end"><span class="d-block fw-semibold small"><?=e($me['name'])?></span><span class="badge role-badge tw-inline-flex tw-items-center tw-rounded-full tw-px-2 tw-py-1"><?=e(strtoupper($me['role']))?></span></li>
        <li class="nav-item"><a class="btn btn-sm btn-outline-primary" href="logout.php"><i class="bi bi-box-arrow-right me-1"></i>Keluar</a></li>
      </ul>
    </div>
  </nav>

  <div class="sidebar-backdrop" data-sidebar-backdrop aria-hidden="true"></div>
  <aside class="app-sidebar shadow" data-bs-theme="dark">
    <div class="sidebar-brand">
      <a href="index.php" class="brand-link text-decoration-none d-flex align-items-center gap-2">
        <span class="brand-mark"><i class="bi bi-car-front-fill"></i></span>
        <span class="brand-text fw-bold">SIDARA</span>
      </a>
    </div>
    <div class="sidebar-wrapper">
      <nav class="mt-2">
        <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="navigation" aria-label="Navigasi utama" data-accordion="false">
          <li class="nav-header">MENU UTAMA</li>
          <li class="nav-item"><a href="index.php" class="nav-link <?=menu_active(['index.php'])?>"><i class="nav-icon bi bi-speedometer2"></i><p>Dashboard</p></a></li>
          <?php if($me['role']==='admin'): ?>
          <li class="nav-item"><a href="users.php" class="nav-link <?=menu_active(['users.php'])?>"><i class="nav-icon bi bi-people"></i><p>Kelola Pengguna</p></a></li>
          <?php endif; ?>
          <li class="nav-item"><a href="vehicles.php" class="nav-link <?=menu_active(['vehicles.php'])?>"><i class="nav-icon bi bi-car-front"></i><p>Data Kendaraan</p></a></li>
          <li class="nav-item"><a href="trips.php" class="nav-link <?=menu_active(['trips.php','trip_form.php','trip_detail.php'])?>"><i class="nav-icon bi bi-signpost-2"></i><p>Perjalanan Dinas</p></a></li>
          <li class="nav-header">OPERASIONAL</li>
          <?php if(in_array($me['role'],['admin','finance'],true)): ?>
          <li class="nav-item"><a href="finance.php" class="nav-link <?=menu_active(['finance.php'])?>"><i class="nav-icon bi bi-wallet2"></i><p>Persetujuan & Keuangan</p></a></li>
          <?php endif; ?>
          <li class="nav-item"><a href="maintenance.php" class="nav-link <?=menu_active(['maintenance.php'])?>"><i class="nav-icon bi bi-wrench-adjustable"></i><p>Servis & Perbaikan</p></a></li>
          <?php if(in_array($me['role'],['admin','finance'],true)): ?>
          <li class="nav-item"><a href="reports.php" class="nav-link <?=menu_active(['reports.php'])?>"><i class="nav-icon bi bi-file-earmark-bar-graph"></i><p>Laporan</p></a></li>
          <?php endif; ?>
          <li class="nav-header">AKUN</li>
          <li class="nav-item"><a href="logout.php" class="nav-link"><i class="nav-icon bi bi-box-arrow-right"></i><p>Keluar</p></a></li>
        </ul>
      </nav>
    </div>
    <div class="sidebar-user"><div class="sidebar-user-avatar"><i class="bi bi-person-fill"></i></div><div class="min-w-0"><div class="fw-semibold text-truncate"><?=e($me['name'])?></div><div class="small text-white-50"><?=e(ucfirst($me['role']))?></div></div></div>
  </aside>

  <main class="app-main">
    <div class="app-content-header">
      <div class="container-fluid">
        <div class="row align-items-center g-2">
          <div class="col-sm-8"><h3 class="mb-0 page-heading"><?=e($page_title)?></h3><div class="page-subtitle">Kelola perjalanan, armada, dan pertanggungjawaban biaya dalam satu sistem.</div></div>
          <div class="col-sm-4"><ol class="breadcrumb float-sm-end mb-0"><li class="breadcrumb-item"><a href="index.php">SIDARA</a></li><li class="breadcrumb-item active" aria-current="page"><?=e($page_title)?></li></ol></div>
        </div>
      </div>
    </div>
    <div class="app-content"><div class="container-fluid content-container">
