<?php
require_once __DIR__ . '/auth.php';
require_role(['admin', 'finance']);
$page_title = 'Laporan';
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');

$sql = "SELECT t.id, t.destination, t.departure_date, t.actual_return, t.status,
               t.advance_amount, u.name AS driver_name, v.plate_number,
               COALESCE(SUM(CASE WHEN e.status='disetujui' THEN e.amount ELSE 0 END),0) AS approved_cost,
               COALESCE(SUM(CASE WHEN e.status='menunggu' THEN e.amount ELSE 0 END),0) AS pending_cost
        FROM trips t
        JOIN users u ON u.id=t.driver_id
        LEFT JOIN vehicles v ON v.id=t.vehicle_id
        LEFT JOIN trip_expenses e ON e.trip_id=t.id
        WHERE t.departure_date BETWEEN ? AND ?
        GROUP BY t.id, t.destination, t.departure_date, t.actual_return, t.status,
                 t.advance_amount, u.name, v.plate_number
        ORDER BY t.departure_date DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$from, $to]);
$rows = $stmt->fetchAll();
$sumAdvance = $sumCost = $sumPending = 0;
foreach ($rows as $r) {
    $sumAdvance += (float)$r['advance_amount'];
    $sumCost += (float)$r['approved_cost'];
    $sumPending += (float)$r['pending_cost'];
}

// Export Excel-compatible CSV without loading the HTML layout.
if (($_GET['export'] ?? '') === 'excel') {
    $filename = 'laporan_sidara_' . $from . '_sampai_' . $to . '.csv';
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('X-Content-Type-Options: nosniff');
    $out = fopen('php://output', 'w');
    // UTF-8 BOM helps Microsoft Excel open Indonesian text correctly.
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['Laporan Perjalanan Dinas SIDARA']);
    fputcsv($out, ['Periode', $from, 'sampai', $to]);
    fputcsv($out, []);
    fputcsv($out, ['Tanggal', 'Driver', 'Kendaraan', 'Tujuan', 'Status', 'Uang Muka', 'Biaya Disetujui', 'Biaya Menunggu', 'Sisa / Kurang']);
    foreach ($rows as $r) {
        fputcsv($out, [$r['departure_date'], $r['driver_name'], $r['plate_number'] ?? '-', $r['destination'], str_replace('_', ' ', $r['status']), (float)$r['advance_amount'], (float)$r['approved_cost'], (float)$r['pending_cost'], (float)$r['advance_amount'] - (float)$r['approved_cost']]);
    }
    fputcsv($out, ['TOTAL', '', '', '', '', $sumAdvance, $sumCost, $sumPending, $sumAdvance - $sumCost]);
    fclose($out);
    exit;
}
require __DIR__ . '/includes/header.php';
$exportUrl = '?' . http_build_query(['from' => $from, 'to' => $to, 'export' => 'excel']);
?>
<div class="card mb-4 no-print"><div class="card-body"><form class="row g-3 align-items-end" method="get">
  <div class="col-12 col-md-4"><label class="form-label">Dari tanggal</label><input class="form-control" type="date" name="from" value="<?=e($from)?>"></div>
  <div class="col-12 col-md-4"><label class="form-label">Sampai tanggal</label><input class="form-control" type="date" name="to" value="<?=e($to)?>"></div>
  <div class="col-12 col-md-4 d-flex flex-wrap gap-2"><button class="btn btn-primary" type="submit"><i class="bi bi-funnel me-1"></i>Tampilkan</button><a class="btn btn-success" href="<?=e($exportUrl)?>"><i class="bi bi-file-earmark-excel me-1"></i>Export Excel</a><button type="button" onclick="window.print()" class="btn btn-outline-secondary"><i class="bi bi-printer me-1"></i>Cetak / PDF</button></div>
</form></div></div>
<div class="row g-3 mb-4">
  <div class="col-12 col-md-4"><div class="card h-100"><div class="card-body"><div class="small-muted">Total uang muka</div><div class="stat-number"><?=rupiah($sumAdvance)?></div></div></div></div>
  <div class="col-12 col-md-4"><div class="card h-100"><div class="card-body"><div class="small-muted">Biaya disetujui</div><div class="stat-number"><?=rupiah($sumCost)?></div></div></div></div>
  <div class="col-12 col-md-4"><div class="card h-100"><div class="card-body"><div class="small-muted">Biaya menunggu</div><div class="stat-number"><?=rupiah($sumPending)?></div></div></div></div>
</div>
<div class="card"><div class="card-header bg-white py-3"><h5 class="mb-0">Rekap perjalanan</h5><div class="small-muted">Periode <?=e($from)?> sampai <?=e($to)?></div></div><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Tanggal</th><th>Driver</th><th>Kendaraan</th><th>Tujuan</th><th>Status</th><th>Uang muka</th><th>Biaya disetujui</th><th>Biaya menunggu</th><th>Sisa / kurang</th></tr></thead><tbody>
<?php foreach ($rows as $r): $bal = (float)$r['advance_amount'] - (float)$r['approved_cost']; ?>
<tr><td><?=e($r['departure_date'])?></td><td><?=e($r['driver_name'])?></td><td><?=e($r['plate_number'] ?? '-')?></td><td><?=e($r['destination'])?></td><td><?=e(str_replace('_', ' ', $r['status']))?></td><td><?=rupiah($r['advance_amount'])?></td><td><?=rupiah($r['approved_cost'])?></td><td><?=rupiah($r['pending_cost'])?></td><td class="<?=$bal < 0 ? 'text-danger' : 'text-success'?> fw-semibold"><?=rupiah($bal)?></td></tr>
<?php endforeach; if (!$rows): ?><tr><td colspan="9" class="empty-state">Tidak ada perjalanan dalam periode ini.</td></tr><?php endif; ?>
</tbody><tfoot><tr class="fw-bold"><td colspan="5">TOTAL</td><td><?=rupiah($sumAdvance)?></td><td><?=rupiah($sumCost)?></td><td><?=rupiah($sumPending)?></td><td><?=rupiah($sumAdvance - $sumCost)?></td></tr></tfoot></table></div></div>
<div class="small-muted mt-3">Catatan: biaya menunggu verifikasi ditampilkan terpisah. Sisa / kurang dihitung dari uang muka dikurangi biaya yang disetujui.</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
