# POS Percetakan v26 - Persediaan / Stok

## Fitur
- Produk memiliki stok dan stok minimum.
- Jasa tidak menggunakan stok.
- Penjualan otomatis mengurangi stok.
- Penjualan ditolak jika stok tidak cukup.
- Pembatalan pesanan mengembalikan stok.
- Pesanan yang batal lalu diaktifkan kembali akan memotong stok lagi.
- Stok masuk dan penyesuaian dapat dilakukan dari Persediaan.
- Semua perubahan dicatat pada `stock_movements`.
- Export Produk & Jasa membawa jenis, stok, dan stok minimum.
- Template import Excel diperbarui dengan `jenis`, `stok_awal`, dan `stok_minimum`.

## Instalasi database baru
Gunakan `database/pos_percetakan.sql`.

## Instalasi pada database v25 yang sudah berisi data
Backup database terlebih dahulu, lalu jalankan `database/upgrade_stok.sql` satu kali.

Catatan: produk lama otomatis menjadi `PRODUCT` dengan stok `0`. Isi stok awal melalui menu Persediaan agar histori mutasinya tercatat.
