<?php
$title='Manajemen Pengguna & Hak Akses';
require_once __DIR__.'/../includes/header.php';
require_admin();
$pdo=db();
$permissions=$pdo->query('SELECT * FROM permissions ORDER BY sort_order,id')->fetchAll();
$roles=['admin'=>'Administrator','manager'=>'Manager','kasir'=>'Kasir','produksi'=>'Produksi'];
$editId=(int)($_GET['edit']??0);
$edit=null;$editPerm=[];
if($editId){$q=$pdo->prepare('SELECT id,username,name,role,active FROM users WHERE id=?');$q->execute([$editId]);$edit=$q->fetch();$editPerm=user_permissions($editId);}
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();
 $action=$_POST['action']??'';
 try{
  if($action==='save'){
   $id=(int)($_POST['id']??0);$name=trim($_POST['name']??'');$username=trim($_POST['username']??'');$role=array_key_exists($_POST['role']??'', $roles)?$_POST['role']:'kasir';$active=isset($_POST['active'])?1:0;
   if($name===''||$username==='') throw new RuntimeException('Nama dan username wajib diisi.');
   if(!$id){$pass=$_POST['password']??'';if(strlen($pass)<6)throw new RuntimeException('Password minimal 6 karakter.');$pdo->prepare('INSERT INTO users(username,password,name,role,active) VALUES(?,?,?,?,?)')->execute([$username,password_hash($pass,PASSWORD_DEFAULT),$name,$role,$active]);$id=(int)$pdo->lastInsertId();activity_log('user.create','Membuat pengguna '.$username);}
   else {$pdo->prepare('UPDATE users SET username=?,name=?,role=?,active=? WHERE id=?')->execute([$username,$name,$role,$active,$id]);if(trim($_POST['password']??'')){if(strlen($_POST['password'])<6)throw new RuntimeException('Password minimal 6 karakter.');$pdo->prepare('UPDATE users SET password=? WHERE id=?')->execute([password_hash($_POST['password'],PASSWORD_DEFAULT),$id]);}activity_log('user.update','Memperbarui pengguna '.$username);}
   $pdo->prepare('DELETE FROM user_permissions WHERE user_id=?')->execute([$id]);
   $ins=$pdo->prepare('INSERT INTO user_permissions(user_id,permission_id,allowed) VALUES(?,?,1)');
   foreach(($_POST['permissions']??[]) as $pid){$pid=(int)$pid;if($pid>0)$ins->execute([$id,$pid]);}
   flash('success','Pengguna dan hak akses berhasil disimpan.');redirect('/master/pengguna.php');
  }
  if($action==='delete'){
   $id=(int)$_POST['id'];if($id===(int)current_user()['id'])throw new RuntimeException('Akun yang sedang digunakan tidak dapat dihapus.');
   $q=$pdo->prepare('SELECT username FROM users WHERE id=?');$q->execute([$id]);$un=$q->fetchColumn();$pdo->prepare('DELETE FROM users WHERE id=?')->execute([$id]);activity_log('user.delete','Menghapus pengguna '.$un);flash('success','Pengguna dihapus.');redirect('/master/pengguna.php');
  }
 }catch(PDOException $e){flash('danger',str_contains($e->getMessage(),'Duplicate')?'Username sudah digunakan.':'Gagal menyimpan pengguna.');redirect('/master/pengguna.php'.($editId?'?edit='.$editId:''));}catch(Throwable $e){flash('danger',$e->getMessage());redirect('/master/pengguna.php');}
}
$rows=$pdo->query('SELECT u.id,u.username,u.name,u.role,u.active,u.created_at,(SELECT COUNT(*) FROM user_activity_logs l WHERE l.user_id=u.id) activity_count FROM users u ORDER BY FIELD(u.role,"admin","manager","kasir","produksi"),u.name')->fetchAll();
$groups=[];foreach($permissions as $p)$groups[$p['module']][]=$p;
?>
<div class="page-head"><div><h2 style="margin:0">Manajemen Pengguna</h2><p class="muted">Kelola akun, role, status dan hak akses secara granular.</p></div><a class="btn" href="<?=BASE_URL?>/master/pengguna.php">+ Pengguna Baru</a></div>
<div class="grid grid-2">
<div class="card">
<b><?= $edit?'Edit Pengguna':'Tambah Pengguna' ?></b>
<form method="post" style="margin-top:14px">
<input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=e((string)($edit['id']??0))?>">
<div class="form-grid"><div class="form-group"><label>Nama Lengkap</label><input class="form-control" name="name" required value="<?=e($edit['name']??'')?>"></div><div class="form-group"><label>Username</label><input class="form-control" name="username" required value="<?=e($edit['username']??'')?>"></div></div>
<div class="form-grid" style="margin-top:10px"><div class="form-group"><label>Password <?= $edit?'<small>(kosongkan jika tidak diubah)</small>':''?></label><input class="form-control" type="password" name="password" <?= $edit?'':'required' ?> minlength="6"></div><div class="form-group"><label>Role</label><select class="form-control" name="role"><?php foreach($roles as $k=>$v):?><option value="<?=e($k)?>" <?=($edit['role']??'kasir')===$k?'selected':''?>><?=e($v)?></option><?php endforeach;?></select></div></div>
<label style="display:block;margin-top:12px"><input type="checkbox" name="active" <?=(!$edit||$edit['active'])?'checked':''?>> Akun aktif dan dapat login</label>
<div style="margin-top:18px"><b>Hak Akses Khusus Pengguna</b><p class="muted" style="margin:4px 0 10px">Centang untuk memberikan akses tambahan/override. Role menjadi dasar hak akses.</p>
<?php foreach($groups as $module=>$items):?><div class="permission-box"><strong><?=e($module)?></strong><?php foreach($items as $p):?><label><input type="checkbox" name="permissions[]" value="<?=$p['id']?>" <?=isset($editPerm[$p['permission_key']])&&$editPerm[$p['permission_key']]==1?'checked':''?>> <?=e($p['permission_name'])?></label><?php endforeach;?></div><?php endforeach;?></div>
<button class="btn" style="margin-top:14px">Simpan Pengguna</button><?php if($edit):?> <a class="btn secondary" href="<?=BASE_URL?>/master/pengguna.php">Batal</a><?php endif; ?></form></div>
<div class="card"><div style="display:flex;justify-content:space-between;align-items:center"><b>Daftar Pengguna</b><span class="badge green"><?=count($rows)?> akun</span></div><div class="table-wrap" style="margin-top:10px"><table class="table"><thead><tr><th>Pengguna</th><th>Role</th><th>Status</th><th>Aktivitas</th><th></th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><b><?=e($r['name'])?></b><br><small class="muted">@<?=e($r['username'])?></small></td><td><?=e($roles[$r['role']]??$r['role'])?></td><td><span class="badge <?=$r['active']?'green':'red'?>"><?=$r['active']?'Aktif':'Nonaktif'?></span></td><td><?=number_format((int)$r['activity_count'])?></td><td><a class="btn small secondary" href="?edit=<?=$r['id']?>">Edit</a> <?php if($r['id']!=(int)current_user()['id']):?><form method="post" style="display:inline" onsubmit="return confirm('Hapus pengguna ini?')"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn small danger">Hapus</button></form><?php endif;?></td></tr><?php endforeach;?></tbody></table></div></div></div>
<style>.permission-box{border:1px solid #e5e7eb;border-radius:10px;padding:10px;margin-top:8px;background:#fafafa}.permission-box label{display:block;padding:5px 0;font-size:13px}.muted{color:#6b7280;font-size:13px}.page-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}.btn.small{padding:6px 9px;font-size:12px}.btn.secondary{background:#eef2f7;color:#111}.btn.danger{background:#dc3545;color:#fff}</style>
<?php require __DIR__.'/../includes/footer.php'; ?>
