<?php
$title='Persediaan / Stok'; require_once __DIR__.'/../includes/header.php'; require_permission('stock.manage'); $pdo=db();
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check(); $id=(int)($_POST['product_id']??0); $type=$_POST['movement_type']??'IN'; $qty=abs((float)($_POST['qty']??0)); $notes=trim($_POST['notes']??'');
 try{
  if($qty<=0)throw new RuntimeException('Jumlah harus lebih dari 0.');
  if(!in_array($type,['IN','ADJUSTMENT'],true))throw new RuntimeException('Jenis mutasi tidak valid.');
  $pdo->beginTransaction(); $q=$pdo->prepare("SELECT id,name,unit,item_type,stock FROM products WHERE id=? AND active=1 FOR UPDATE");$q->execute([$id]);$p=$q->fetch();if(!$p)throw new RuntimeException('Produk tidak ditemukan.');if($p['item_type']!=='PRODUCT')throw new RuntimeException('Jasa tidak memiliki stok.');
  $before=(float)$p['stock']; $after=$type==='IN'?$before+$qty:$qty; $delta=$type==='IN'?$qty:$after-$before; 
  if($type==='ADJUSTMENT' && $after<0)throw new RuntimeException('Stok tidak boleh minus.');
  $u=$pdo->prepare('UPDATE products SET stock=? WHERE id=?');$u->execute([$after,$id]);
  $m=$pdo->prepare("INSERT INTO stock_movements(product_id,movement_type,qty,stock_before,stock_after,reference_type,notes,user_id) VALUES(?,?,?,?,?,?,?,?)");$m->execute([$id,$type,abs($delta),$before,$after,'MANUAL',$notes?:($type==='IN'?'Stok masuk':'Penyesuaian stok'),current_user()['id']??null]);
  $pdo->commit(); flash('success','Stok '.$p['name'].' berhasil diperbarui.');
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();flash('danger','Gagal mengubah stok: '.$e->getMessage());}
 redirect('/master/stok.php');
}
$search=trim($_GET['q']??'');
$sort=$_GET['sort']??'stock';
$dir=strtolower($_GET['dir']??'asc');
$perPage=(int)($_GET['per_page']??25);
$page=max(1,(int)($_GET['page']??1));
if(!in_array($sort,['stock','min_stock','name','code'],true))$sort='stock';
if(!in_array($dir,['asc','desc'],true))$dir='asc';
if(!in_array($perPage,[10,25,50,100],true))$perPage=25;
$where="WHERE p.active=1 AND p.item_type='PRODUCT'";
$params=[];
if($search!==''){
 $where.=' AND (p.name LIKE ? OR p.code LIKE ? OR p.barcode LIKE ?)';
 $like='%'.$search.'%';$params=[$like,$like,$like];
}
$count=$pdo->prepare("SELECT COUNT(*) FROM products p $where");$count->execute($params);$total=(int)$count->fetchColumn();
$totalPages=max(1,(int)ceil($total/$perPage));
$page=min($page,$totalPages);$offset=($page-1)*$perPage;
$orderMap=[
 'stock'=>'p.stock',
 'min_stock'=>'p.min_stock',
 'name'=>'p.name',
 'code'=>'p.code'
];
$orderBy=$orderMap[$sort];
$q=$pdo->prepare("SELECT p.*,c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id $where ORDER BY $orderBy $dir, p.name ASC LIMIT ? OFFSET ?");
$bind=$params;$bind[]=$perPage;$bind[]=$offset;
foreach($bind as $i=>$v)$q->bindValue($i+1,$v,is_int($v)?PDO::PARAM_INT:PDO::PARAM_STR);
$q->execute();$rows=$q->fetchAll();
$products=$pdo->query("SELECT id,code,name,unit,stock FROM products WHERE active=1 AND item_type='PRODUCT' ORDER BY name")->fetchAll();

function stok_url(array $overrides=[]): string {
 $params=$_GET;
 foreach($overrides as $k=>$v){if($v===null)unset($params[$k]);else $params[$k]=$v;}
 return BASE_URL.'/master/stok.php'.($params?'?'.http_build_query($params):'');
}
function stok_sort_link(string $field,string $label,string $current,string $dir): string {
 $next=($current===$field && $dir==='asc')?'desc':'asc';
 $arrow=$current===$field?($dir==='asc'?' ↑':' ↓'):'';
 return '<a class="stock-sort" href="'.e(stok_url(['sort'=>$field,'dir'=>$next,'page'=>1])).'">'.e($label).$arrow.'</a>';
}
?>

<div class="toolbar"><div><b>Persediaan / Stok</b><div class="muted">Kelola stok masuk dan penyesuaian. Penjualan otomatis mengurangi stok.</div></div><div class="actions"><a class="btn secondary" href="<?=BASE_URL?>/master/mutasi_stok.php">📜 Riwayat Mutasi</a></div></div>
<div class="grid grid-2">
<div class="card"><b>Tambah / Penyesuaian Stok</b><form method="post" style="margin-top:14px"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><div class="form-group"><label>Produk</label><select class="form-control" name="product_id" required><option value="">Pilih produk...</option><?php foreach($products as $p):?><option value="<?=$p['id']?>"><?=e($p['code'].' - '.$p['name'].' (stok '.rtrim(rtrim(number_format((float)$p['stock'],2,'.',''),'0'),'.').' '.$p['unit'].')')?></option><?php endforeach;?></select></div><div class="form-group" style="margin-top:10px"><label>Jenis</label><select class="form-control" name="movement_type"><option value="IN">Stok Masuk / Tambah</option><option value="ADJUSTMENT">Set Stok Aktual</option></select></div><div class="form-group" style="margin-top:10px"><label>Jumlah</label><input class="form-control" type="number" name="qty" min="0.01" step="0.01" required></div><div class="form-group" style="margin-top:10px"><label>Catatan</label><input class="form-control" name="notes" placeholder="Contoh: Pembelian supplier / stock opname"></div><button class="btn" style="margin-top:12px">Simpan Mutasi</button></form><div class="alert" style="margin-top:14px">Untuk <b>Set Stok Aktual</b>, angka yang dimasukkan adalah saldo stok akhir, bukan jumlah selisih.</div></div>
<div class="card stock-list-card"><div class="stock-list-head"><form class="product-filter" method="get"><input type="hidden" name="sort" value="<?=e($sort)?>"><input type="hidden" name="dir" value="<?=e($dir)?>"><input type="hidden" name="per_page" value="<?=e($perPage)?>"><input class="form-control" name="q" value="<?=e($search)?>" placeholder="Cari produk, kode atau barcode..."><button class="btn secondary">Cari</button><?php if($search!==''):?><a class="btn secondary" href="<?=BASE_URL?>/master/stok.php">Reset</a><?php endif;?></form><div class="stock-list-meta"><span>Menampilkan <b><?=$total?($offset+1):0?>–<?=min($offset+$perPage,$total)?></b> dari <b><?=$total?></b> produk</span><label>Per halaman <select onchange="location.href=this.value"><option value="<?=e(stok_url(['per_page'=>10,'page'=>1]))?>" <?=$perPage===10?'selected':''?>>10</option><option value="<?=e(stok_url(['per_page'=>25,'page'=>1]))?>" <?=$perPage===25?'selected':''?>>25</option><option value="<?=e(stok_url(['per_page'=>50,'page'=>1]))?>" <?=$perPage===50?'selected':''?>>50</option><option value="<?=e(stok_url(['per_page'=>100,'page'=>1]))?>" <?=$perPage===100?'selected':''?>>100</option></select></label></div></div><div class="stock-sort-note">Klik judul <b>Stok</b> atau <b>Minimum</b> untuk mengurutkan. Panah menunjukkan urutan aktif.</div><div class="table-wrap"><table class="table"><thead><tr><th><?=stok_sort_link('code','Kode',$sort,$dir)?></th><th><?=stok_sort_link('name','Produk',$sort,$dir)?></th><th><?=stok_sort_link('stock','Stok',$sort,$dir)?></th><th><?=stok_sort_link('min_stock','Minimum',$sort,$dir)?></th><th>Status</th></tr></thead><tbody><?php foreach($rows as $r):$low=(float)$r['stock']<=(float)$r['min_stock'];?><tr><td><?=e($r['code'])?></td><td><strong><?=e($r['name'])?></strong><div class="muted"><?=e($r['category']??'-')?> · <?=e($r['unit'])?></div></td><td><strong class="<?=$low?'stock-low':''?>"><?=e(rtrim(rtrim(number_format((float)$r['stock'],2,'.',''),'0'),'.'))?></strong></td><td><?=e(rtrim(rtrim(number_format((float)$r['min_stock'],2,'.',''),'0'),'.'))?></td><td><span class="badge <?=$low?'red':'green'?>"><?=$low?'Stok Menipis':'Aman'?></span></td></tr><?php endforeach;if(!$rows):?><tr><td colspan="5" class="muted">Tidak ada produk.</td></tr><?php endif;?></tbody></table></div><?php if($totalPages>1):?><div class="stock-pagination"><div class="pagination-info">Halaman <?=$page?> dari <?=$totalPages?></div><div class="pagination"><a class="page-link <?=$page<=1?'disabled':''?>" href="<?=e(stok_url(['page'=>1]))?>">«</a><a class="page-link <?=$page<=1?'disabled':''?>" href="<?=e(stok_url(['page'=>max(1,$page-1)]))?>">‹</a><?php $startPage=max(1,$page-2);$endPage=min($totalPages,$page+2);for($pg=$startPage;$pg<=$endPage;$pg++):?><a class="page-link <?=$pg===$page?'active':''?>" href="<?=e(stok_url(['page'=>$pg]))?>"><?=$pg?></a><?php endfor;?><a class="page-link <?=$page>=$totalPages?'disabled':''?>" href="<?=e(stok_url(['page'=>min($totalPages,$page+1)]))?>">›</a><a class="page-link <?=$page>=$totalPages?'disabled':''?>" href="<?=e(stok_url(['page'=>$totalPages]))?>">»</a></div></div><?php endif;?></div></div>
<?php require __DIR__.'/../includes/footer.php'; ?>
