<?php
declare(strict_types=1);
require_once __DIR__.'/../config/config.php';
require_permission('products.manage');
$pdo = db();
$rows = $pdo->query("SELECT p.code,p.barcode,p.name,p.unit,p.price,p.cost_price,p.item_type,p.stock,p.min_stock,p.active,c.name category,pc.name parent_category FROM products p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN categories pc ON pc.id=c.parent_id ORDER BY pc.name,c.name,p.name")->fetchAll();
function xe(string $v): string { return htmlspecialchars($v, ENT_XML1|ENT_QUOTES, 'UTF-8'); }
function ssCell(string $v, string $type='String', string $style=''): string { return '<Cell'.($style?' ss:StyleID="'.$style.'"':'').'><Data ss:Type="'.$type.'">'.xe($v).'</Data></Cell>'; }
$xml='<?xml version="1.0"?>'."\n";
$xml.='<?mso-application progid="Excel.Sheet"?>'."\n";
$xml.='<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">';
$xml.='<Styles><Style ss:ID="Header"><Font ss:Bold="1"/><Interior ss:Color="#D9EAF7" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center"/></Style><Style ss:ID="Currency"><NumberFormat ss:Format="#,##0"/></Style></Styles>';
$xml.='<Worksheet ss:Name="Produk &amp; Jasa"><Table><Column ss:Width="100"/><Column ss:Width="110"/><Column ss:Width="220"/><Column ss:Width="140"/><Column ss:Width="140"/><Column ss:Width="70"/><Column ss:Width="100"/><Column ss:Width="100"/><Column ss:Width="80"/><Column ss:Width="100"/><Column ss:Width="90"/><Column ss:Width="90"/><Column ss:Width="120"/><Column ss:Width="140"/>';
$headers=['Kode','Barcode','Nama Produk / Jasa','Kategori Induk','Kategori','Satuan','Harga Jual','Harga Modal','Jenis','Stok','Stok Minimum','Status'];
$xml.='<Row>'; foreach($headers as $h)$xml.=ssCell($h,'String','Header'); $xml.='</Row>';
foreach($rows as $p){$xml.='<Row>'; $xml.=ssCell((string)$p['code']);$xml.=ssCell((string)($p['barcode']??''));$xml.=ssCell((string)$p['name']);$xml.=ssCell((string)($p['parent_category']??''));$xml.=ssCell((string)($p['category']??''));$xml.=ssCell((string)$p['unit']);$xml.=ssCell(number_format((float)$p['price'],0,'.',''),'Number','Currency');$xml.=ssCell(number_format((float)$p['cost_price'],0,'.',''),'Number','Currency');$xml.=ssCell($p['item_type']==='SERVICE'?'Jasa':'Produk');$xml.=ssCell(number_format((float)$p['stock'],2,'.',''),'Number');$xml.=ssCell(number_format((float)$p['min_stock'],2,'.',''),'Number');$xml.=ssCell((int)$p['active']?'Aktif':'Nonaktif');$xml.='</Row>';}
$xml.='</Table><WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel"><FreezePanes/><FrozenNoSplit/><SplitHorizontal>1</SplitHorizontal><TopRowBottomPane>1</TopRowBottomPane><AutoFilter x:Range="R1C1:R'.(count($rows)+1).'C12" xmlns="urn:schemas-microsoft-com:office:excel"/></WorksheetOptions></Worksheet></Workbook>';
$filename='produk-jasa-'.date('Ymd-His').'.xls';
header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
header('Content-Disposition: attachment; filename="'.$filename.'"');
header('Cache-Control: no-store, no-cache, must-revalidate');
echo $xml; exit;
