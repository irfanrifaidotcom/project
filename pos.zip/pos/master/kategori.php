<?php
$title='Kategori Produk';
require_once __DIR__.'/../includes/header.php';
require_permission('categories.manage');
$pdo=db();

function category_children(array $rows, ?int $parentId): array {
    $out=[];
    foreach($rows as $row){
        $pid=$row['parent_id']===null ? null : (int)$row['parent_id'];
        if($pid === $parentId) $out[]=$row;
    }
    usort($out, fn($a,$b)=>strnatcasecmp($a['name'],$b['name']));
    return $out;
}
function sort_category_nodes(array $nodes): array { usort($nodes, fn($a,$b)=>strnatcasecmp($a['name'],$b['name'])); return $nodes; }
function category_descendants(array $children, int $id): array {
    $ids=[];
    foreach($children[$id]??[] as $child){
        $cid=(int)$child['id']; $ids[]=$cid; $ids=array_merge($ids,category_descendants($children,$cid));
    }
    return $ids;
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_check();
    $action=$_POST['action']??'save';
    try{
        if($action==='delete'){
            $id=(int)($_POST['id']??0);
            if(!$id) throw new RuntimeException('Kategori tidak valid.');
            $q=$pdo->prepare('SELECT name FROM categories WHERE id=?'); $q->execute([$id]); $cat=$q->fetch();
            if(!$cat) throw new RuntimeException('Kategori tidak ditemukan.');
            $q=$pdo->prepare('SELECT COUNT(*) FROM categories WHERE parent_id=?'); $q->execute([$id]);
            if((int)$q->fetchColumn()>0) throw new RuntimeException('Kategori masih memiliki subkategori. Pindahkan atau hapus subkategori terlebih dahulu.');
            $q=$pdo->prepare('SELECT COUNT(*) FROM products WHERE category_id=?'); $q->execute([$id]);
            if((int)$q->fetchColumn()>0) throw new RuntimeException('Kategori masih digunakan produk. Pindahkan produk terlebih dahulu.');
            $pdo->prepare('DELETE FROM categories WHERE id=?')->execute([$id]);
            activity_log('HAPUS_KATEGORI','Menghapus kategori: '.$cat['name']);
            flash('success','Kategori berhasil dihapus.');
        } else {
            $id=(int)($_POST['id']??0);
            $parentId=(int)($_POST['parent_id']??0); $parentId=$parentId?:null;
            $name=trim($_POST['name']??''); $description=trim($_POST['description']??''); $active=isset($_POST['active'])?1:0;
            if($name==='') throw new RuntimeException('Nama kategori wajib diisi.');
            if($id && $parentId===$id) throw new RuntimeException('Kategori tidak boleh menjadi induknya sendiri.');
            if($id){
                $q=$pdo->prepare('SELECT id,parent_id FROM categories WHERE id=?'); $q->execute([$id]); $old=$q->fetch();
                if(!$old) throw new RuntimeException('Kategori tidak ditemukan.');
                if($parentId!==null){
                    $all=$pdo->query('SELECT id,parent_id FROM categories')->fetchAll(); $parentMap=[]; foreach($all as $r)$parentMap[(int)$r['id']]=$r['parent_id']===null?null:(int)$r['parent_id'];
                    $cursor=$parentId; while($cursor!==null){ if($cursor===$id) throw new RuntimeException('Tidak dapat memindahkan kategori ke dalam turunannya sendiri.'); $cursor=$parentMap[$cursor]??null; }
                }
                $q=$pdo->prepare('SELECT COUNT(*) FROM categories WHERE parent_id <=> ? AND name=? AND id<>?'); $q->execute([$parentId,$name,$id]);
                if((int)$q->fetchColumn()>0) throw new RuntimeException('Nama kategori sudah digunakan pada level yang sama.');
                $pdo->prepare('UPDATE categories SET parent_id=?,name=?,description=?,active=? WHERE id=?')->execute([$parentId,$name,$description,$active,$id]);
                activity_log('UBAH_KATEGORI','Mengubah kategori: '.$name);
                flash('success','Kategori berhasil diperbarui.');
            } else {
                $q=$pdo->prepare('SELECT COUNT(*) FROM categories WHERE parent_id <=> ? AND name=?'); $q->execute([$parentId,$name]);
                if((int)$q->fetchColumn()>0) throw new RuntimeException('Nama kategori sudah digunakan pada level yang sama.');
                $pdo->prepare('INSERT INTO categories(parent_id,name,description,active) VALUES(?,?,?,?)')->execute([$parentId,$name,$description,$active]);
                activity_log('TAMBAH_KATEGORI','Menambah kategori: '.$name);
                flash('success','Kategori berhasil ditambahkan.');
            }
        }
    }catch(Throwable $e){ flash('danger',$e->getMessage()); }
    redirect('/master/kategori.php');
}

$rows=$pdo->query('SELECT c.*,COUNT(p.id) products FROM categories c LEFT JOIN products p ON p.category_id=c.id GROUP BY c.id ORDER BY c.name')->fetchAll();
$children=[]; foreach($rows as $r){$pid=$r['parent_id']===null?0:(int)$r['parent_id'];$children[$pid][]=$r;}
$edit=null; if(isset($_GET['edit'])){ $q=$pdo->prepare('SELECT * FROM categories WHERE id=?');$q->execute([(int)$_GET['edit']]);$edit=$q->fetch(); }
$roots=category_children($rows,null);
$flatParents=[];
function flatten_category_options(array $nodes,array $children,int $level,array $blocked,&$out): void {
    foreach($nodes as $node){
        $id=(int)$node['id'];
        if(!in_array($id,$blocked,true)){
            $out[]=['id'=>$id,'name'=>str_repeat('— ', $level).$node['name']];
            flatten_category_options(sort_category_nodes($children[$id]??[]),$children,$level+1,$blocked,$out);
        }
    }
}
$blocked=[]; if($edit){ $blocked[]=(int)$edit['id']; $allMap=[]; foreach($rows as $rr)$allMap[(int)$rr['id']]=$rr['parent_id']===null?null:(int)$rr['parent_id']; $stack=[(int)$edit['id']]; while($stack){$x=array_pop($stack); foreach($allMap as $cid=>$pid){if($pid===$x){$blocked[]=$cid;$stack[]=$cid;}}} }
flatten_category_options($roots,$children,0,$blocked,$flatParents);
function render_category_tree(array $nodes,array $children,int $level=0): void {
    foreach($nodes as $r){
        $id=(int)$r['id']; $has=!empty($children[$id]);
        echo '<tr>';
        echo '<td><div class="category-tree-node" style="--level:'.$level.'">'.($level>0?'<span class="tree-line">└─</span>':'').'<span class="category-folder">'.($has?'📂':'📁').'</span><div><strong>'.e($r['name']).'</strong>'.(!empty($r['description'])?'<div class="muted category-desc">'.e($r['description']).'</div>':'').'</div></div></td>';
        echo '<td>'.(int)$r['products'].'</td><td>'.($r['active']?'<span class="badge green">Aktif</span>':'<span class="badge red">Nonaktif</span>').'</td>';
        echo '<td><a class="btn secondary sm" href="?edit='.$id.'">Edit</a> <form method="post" class="inline-form" onsubmit="return confirm(\'Hapus kategori ini?\')"><input type="hidden" name="csrf" value="'.e(csrf_token()).'"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="'.$id.'"><button class="btn danger sm" type="submit">Hapus</button></form></td></tr>';
        if($has) render_category_tree(sort_category_nodes($children[$id]),$children,$level+1);
    }
}
?>
<div class="page-head category-page-head"><div><div class="eyebrow">MASTER DATA</div><h1 class="page-title">Kategori Produk</h1><p class="muted">Kelola kategori induk dan subkategori dalam struktur bertingkat.</p></div><div class="category-stats"><div><strong><?=count($rows)?></strong><span>Total kategori</span></div><div><strong><?=count($roots)?></strong><span>Kategori utama</span></div></div></div>
<div class="category-layout">
<div class="card category-form-card">
 <div class="section-heading"><div><b><?= $edit?'Edit Kategori':'Tambah Kategori' ?></b><span><?= $edit?'Perbarui struktur kategori':'Buat kategori utama atau subkategori baru' ?></span></div><?php if($edit):?><a class="btn secondary sm" href="<?=BASE_URL?>/master/kategori.php">+ Baru</a><?php endif;?></div>
 <form method="post" class="category-form"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=$edit['id']??0?>">
  <div class="form-group"><label>Nama Kategori</label><input class="form-control" name="name" required value="<?=e($edit['name']??'')?>" placeholder="Contoh: RAM, Printer, Banner"></div>
  <div class="form-group"><label>Kategori Induk</label><select class="form-control" name="parent_id"><option value="">— Kategori Utama —</option><?php foreach($flatParents as $root): ?><option value="<?=$root['id']?>" <?=($edit['parent_id']??null)==$root['id']?'selected':''?>><?=e($root['name'])?></option><?php endforeach;?></select><small class="muted">Pilih induk untuk membuat subkategori.</small></div>
  <div class="form-group"><label>Deskripsi</label><textarea class="form-control" name="description" rows="3" placeholder="Keterangan singkat kategori"><?=e($edit['description']??'')?></textarea></div>
  <label class="switch-row"><input type="checkbox" name="active" <?=(!$edit||$edit['active'])?'checked':''?>><span class="switch-ui"></span><span>Aktif</span></label>
  <button class="btn" type="submit"><?= $edit?'Simpan Perubahan':'Tambah Kategori' ?></button>
 </form>
 <div class="category-help"><span>💡</span><div><strong>Contoh struktur</strong><p>Komputer → RAM, SSD, VGA<br>Printer → Tinta, Toner, Cartridge</p></div></div>
</div>
<div class="card category-tree-card">
 <div class="section-heading"><div><b>Struktur Kategori</b><span><?=count($rows)?> kategori terdaftar</span></div><input class="form-control category-search" placeholder="Cari kategori..." oninput="POSApp.filterTable(this,'categoryTable')"></div>
 <div class="table-wrap category-table-wrap"><table class="table category-table" id="categoryTable"><thead><tr><th>Kategori</th><th>Produk</th><th>Status</th><th>Aksi</th></tr></thead><tbody><?php render_category_tree($roots,$children); ?></tbody></table></div>
</div></div>
<?php require __DIR__.'/../includes/footer.php'; ?>
