<?php
$title='Import Produk Masal'; require_once __DIR__.'/../includes/header.php'; require_permission('products.manage');
$pdo=db(); $result=null;

function xlsx_col_to_num(string $col): int { $n=0; for($i=0;$i<strlen($col);$i++) $n=$n*26+(ord(strtoupper($col[$i]))-64); return $n; }
function read_xlsx(string $file): array {
    if(!class_exists('ZipArchive')) throw new RuntimeException('Extension PHP ZipArchive belum aktif.');
    $zip=new ZipArchive(); if($zip->open($file)!==true) throw new RuntimeException('File Excel tidak dapat dibuka.');
    $shared=[]; $ss=$zip->getFromName('xl/sharedStrings.xml');
    if($ss!==false){ $xml=simplexml_load_string($ss); foreach($xml->si as $si){ $txt=''; foreach($si->t as $t)$txt.=(string)$t; foreach($si->r as $r)$txt.=(string)$r->t; $shared[]=$txt; } }
    $wb=simplexml_load_string($zip->getFromName('xl/workbook.xml')); $rels=simplexml_load_string($zip->getFromName('xl/_rels/workbook.xml.rels'));
    $ns='http://schemas.openxmlformats.org/officeDocument/2006/relationships'; $target='xl/worksheets/sheet1.xml';
    if(isset($wb->sheets->sheet[0])){ $rid=(string)$wb->sheets->sheet[0]->attributes($ns)['id']; foreach($rels->Relationship as $rel){ if((string)$rel['Id']===$rid){$t=(string)$rel['Target']; $target=str_starts_with($t,'/')?ltrim($t,'/'):('xl/'.ltrim($t,'/')); break;} } }
    $sheet=$zip->getFromName($target); if($sheet===false) throw new RuntimeException('Sheet pertama tidak ditemukan.'); $xml=simplexml_load_string($sheet); $rows=[];
    foreach($xml->sheetData->row as $row){ $cells=[]; foreach($row->c as $c){ $ref=(string)$c['r']; preg_match('/([A-Z]+)\d+/', $ref,$m); $idx=xlsx_col_to_num($m[1])-1; $v=(string)$c->v; $type=(string)$c['t']; if($type==='s') $v=$shared[(int)$v]??''; elseif($type==='inlineStr') $v=(string)$c->is->t; $cells[$idx]=$v; } if($cells) $rows[]=$cells; }
    $zip->close(); return $rows;
}
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();
 try{
  if(empty($_FILES['excel']['tmp_name']) || $_FILES['excel']['error']!==UPLOAD_ERR_OK) throw new RuntimeException('Silakan pilih file Excel (.xlsx).');
  if($_FILES['excel']['size']>5*1024*1024) throw new RuntimeException('Ukuran file maksimal 5 MB.');
  $ext=strtolower(pathinfo($_FILES['excel']['name'],PATHINFO_EXTENSION)); if($ext!=='xlsx') throw new RuntimeException('Format harus .xlsx.');
  $rows=read_xlsx($_FILES['excel']['tmp_name']); if(count($rows)<2) throw new RuntimeException('File Excel kosong.');
  $headers=array_map(fn($v)=>strtolower(trim((string)$v)),$rows[0]); $expected=['kode','nama','satuan','harga_jual','harga_modal','aktif'];
  $optional=['barcode','kategori_induk','kategori','jenis','stok_awal','stok_minimum'];
  foreach($expected as $h) if(!in_array($h,$headers,true)) throw new RuntimeException('Kolom wajib tidak ditemukan: '.$h);
  $map=array_flip($headers); $insert=0;$update=0;$skip=0;$errors=[]; $pdo->beginTransaction();
  $catStmt=$pdo->prepare('SELECT id FROM categories WHERE name=? AND parent_id <=> ? LIMIT 1');
  $catIns=$pdo->prepare('INSERT INTO categories(parent_id,name,active) VALUES(?,?,1)');
  $find=$pdo->prepare('SELECT id FROM products WHERE code=? LIMIT 1');
  $ins=$pdo->prepare('INSERT INTO products(category_id,code,barcode,name,unit,price,cost_price,item_type,stock,min_stock,active) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
  $upd=$pdo->prepare('UPDATE products SET category_id=?,barcode=?,name=?,unit=?,price=?,cost_price=?,item_type=?,min_stock=?,active=? WHERE code=?');
  for($i=1;$i<count($rows);$i++){
   $r=$rows[$i]; $get=fn($k)=>trim((string)($r[$map[$k]]??'')); $code=$get('kode');$name=$get('nama');
   if($code==='' && $name===''){ $skip++; continue; }
   try{
    if($code===''||$name==='') throw new RuntimeException('Kode dan nama wajib diisi.');
    $parentName=$map && isset($map['kategori_induk'])?$get('kategori_induk'):''; $catName=$map && isset($map['kategori'])?$get('kategori'):''; $catId=null;
    if($catName!==''){
      $parentId=null;
      if($parentName!==''){ $catStmt->execute([$parentName,null]); $parentId=$catStmt->fetchColumn(); if(!$parentId){ $catIns->execute([null,$parentName]); $parentId=(int)$pdo->lastInsertId(); } }
      $catStmt->execute([$catName,$parentId]); $catId=$catStmt->fetchColumn();
      if(!$catId){ $catIns->execute([$parentId,$catName]); $catId=(int)$pdo->lastInsertId(); }
    }
    $barcode=(isset($map['barcode'])?$get('barcode'):'')?:null; $unit=$get('satuan')?:'pcs'; $price=max(0,(float)str_replace([',','.',' '],['','',''],$get('harga_jual'))); $cost=max(0,(float)str_replace([',','.',' '],['','',''],$get('harga_modal'))); $itemType=(isset($map['jenis']) && strtolower($get('jenis'))==='jasa')?'SERVICE':'PRODUCT'; $stock=max(0,(float)(isset($map['stok_awal'])?$get('stok_awal'):0)); $minStock=max(0,(float)(isset($map['stok_minimum'])?$get('stok_minimum'):0)); $active=$get('aktif'); $active=($active===''||in_array(strtolower($active),['1','ya','yes','aktif','true'],true))?1:0;
    $find->execute([$code]); $existing=$find->fetchColumn();
    if($existing){ $upd->execute([$catId,$barcode,$name,$unit,$price,$cost,$itemType,$minStock,$active,$code]); $update++; } else { $ins->execute([$catId,$code,$barcode,$name,$unit,$price,$cost,$itemType,$itemType==='PRODUCT'?$stock:0,$minStock,$active]); $newId=(int)$pdo->lastInsertId(); if($stock>0 && $itemType==='PRODUCT'){ $pdo->prepare("INSERT INTO stock_movements(product_id,movement_type,qty,stock_before,stock_after,reference_type,reference_id,notes,user_id) VALUES(?,?,?,?,?,?,?,?,?)")->execute([$newId,'INITIAL',$stock,0,$stock,'IMPORT',$newId,'Stok awal dari import Excel',current_user()['id']??null]); } $insert++; }
   }catch(Throwable $e){$errors[]='Baris '.($i+1).': '.$e->getMessage();}
  }
  if($errors && $insert===0 && $update===0) $pdo->rollBack(); else $pdo->commit();
  activity_log('IMPORT_PRODUK','Import Excel: '.$insert.' baru, '.$update.' diperbarui, '.count($errors).' error.');
  $result=['ok'=>true,'insert'=>$insert,'update'=>$update,'skip'=>$skip,'errors'=>$errors];
 }catch(Throwable $e){ if($pdo->inTransaction())$pdo->rollBack(); $result=['ok'=>false,'message'=>$e->getMessage()]; }
}
?>
<div class="card">
 <div class="toolbar"><div><h2 style="margin:0">Import Produk Masal</h2><div class="muted">Upload banyak produk sekaligus menggunakan Excel .xlsx</div></div><a class="btn secondary" href="<?=BASE_URL?>/master/produk.php">← Kembali ke Produk</a></div>
 <?php if($result): ?><div class="alert <?=$result['ok']?'success':'danger'?>"><?php if($result['ok']): ?><b>Import selesai.</b> Produk baru: <?=$result['insert']?> · Diperbarui: <?=$result['update']?> · Dilewati: <?=$result['skip']?><?php else: ?><?=e($result['message'])?><?php endif; ?></div><?php if($result['ok']&&$result['errors']): ?><div class="alert danger"><b>Baris yang bermasalah:</b><ul><?php foreach($result['errors'] as $er): ?><li><?=e($er)?></li><?php endforeach;?></ul></div><?php endif; ?><?php endif; ?>
 <div class="grid grid-2" style="margin-top:18px">
  <div><h3>1. Download Format Excel</h3><p class="muted">Gunakan template ini. Jangan mengubah nama kolom pada baris pertama.</p><a class="btn" href="<?=BASE_URL?>/assets/template_produk.xlsx">⬇ Download Template Excel</a></div>
  <div><h3>2. Upload Excel</h3><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input class="form-control" type="file" name="excel" accept=".xlsx" required><small class="muted">Maksimal 5 MB · hanya .xlsx</small><div style="margin-top:14px"><button class="btn">⬆ Import Produk</button></div></form></div>
 </div>
 <hr style="border:0;border-top:1px solid var(--border);margin:24px 0">
 <h3>Format kolom</h3><div class="table-wrap"><table class="table"><thead><tr><th>Kolom</th><th>Wajib</th><th>Contoh</th><th>Keterangan</th></tr></thead><tbody>
 <?php foreach([['kode','Ya','SSD-001','Kode unik produk'],['barcode','Tidak','899000000001','Barcode 1D'],['nama','Ya','SSD NVMe 1TB','Nama produk'],['kategori_induk','Tidak','Komputer','Kategori induk'],['kategori','Tidak','SSD','Subkategori'],['satuan','Tidak','pcs','Default pcs'],['harga_jual','Ya','1050000','Harga jual'],['harga_modal','Tidak','920000','Harga modal'],['jenis','Tidak','Produk/Jasa','Jasa tidak memakai stok'],['stok_awal','Tidak','10','Stok awal produk baru'],['stok_minimum','Tidak','2','Batas peringatan stok menipis'],['aktif','Tidak','1','1/ya/aktif = aktif; 0/tidak = nonaktif']] as $x): ?><tr><td><code><?=e($x[0])?></code></td><td><?=$x[1]?></td><td><?=e($x[2])?></td><td><?=e($x[3])?></td></tr><?php endforeach;?></tbody></table></div>
 <div class="alert" style="margin-top:16px"><b>Catatan:</b> Jika <b>kode</b> sudah ada, data produk tersebut akan <b>diperbarui</b>. Jika kode belum ada, produk baru dibuat. Kategori yang belum ada akan dibuat otomatis.</div>
</div>
<?php require __DIR__.'/../includes/footer.php'; ?>
