<?php
$title='Produk & Jasa'; require_once __DIR__.'/../includes/header.php'; require_permission('products.manage'); $pdo=db();
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check(); $id=(int)($_POST['id']??0); $barcode=trim($_POST['barcode']??'');
 $itemType=(($_POST['item_type']??'PRODUCT')==='SERVICE')?'SERVICE':'PRODUCT'; $minStock=max(0,(float)($_POST['min_stock']??0)); $initialStock=max(0,(float)($_POST['initial_stock']??0));
 $category=(int)($_POST['category_id']??0)?:null; $code=trim($_POST['code']??''); $name=trim($_POST['name']??''); $unit=trim($_POST['unit']??'pcs')?:'pcs'; $price=max(0,(float)($_POST['price']??0)); $cost=max(0,(float)($_POST['cost_price']??0)); $active=isset($_POST['active'])?1:0;
 try{
  $pdo->beginTransaction();
  if($id){
   $q=$pdo->prepare('UPDATE products SET category_id=?,code=?,barcode=?,name=?,unit=?,price=?,cost_price=?,item_type=?,min_stock=?,active=? WHERE id=?');
   $q->execute([$category,$code,$barcode?:null,$name,$unit,$price,$cost,$itemType,$minStock,$active,$id]);
   $pdo->commit(); flash('success','Produk disimpan. Stok dikelola melalui menu Persediaan.');
  }else{
   $q=$pdo->prepare('INSERT INTO products(category_id,code,barcode,name,unit,price,cost_price,item_type,stock,min_stock,active) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
   $q->execute([$category,$code,$barcode?:null,$name,$unit,$price,$cost,$itemType,$itemType==='PRODUCT'?$initialStock:0,$minStock,$active]); $id=(int)$pdo->lastInsertId();
   if(!$barcode){$gen='200'.str_pad((string)$id,9,'0',STR_PAD_LEFT);$u=$pdo->prepare('UPDATE products SET barcode=? WHERE id=?');$u->execute([$gen,$id]);}
   if($initialStock>0 && $itemType==='PRODUCT'){$m=$pdo->prepare("INSERT INTO stock_movements(product_id,movement_type,qty,stock_before,stock_after,reference_type,reference_id,notes,user_id) VALUES(?,?,?,?,?,?,?,?,?)");$m->execute([$id,'INITIAL',$initialStock,0,$initialStock,'PRODUCT',$id,'Stok awal produk',current_user()['id']??null]);}
   $pdo->commit(); flash('success','Produk berhasil ditambahkan.');
  }
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();flash('danger','Gagal menyimpan: '.$e->getMessage());}
 redirect('/master/produk.php'.($id?'?edit='.$id:''));
}
$cats=$pdo->query('SELECT c.*,pc.name parent_name FROM categories c LEFT JOIN categories pc ON pc.id=c.parent_id WHERE c.active=1 ORDER BY COALESCE(pc.name,c.name), c.parent_id, c.name')->fetchAll();
$edit=null;if(isset($_GET['edit'])){$q=$pdo->prepare('SELECT * FROM products WHERE id=?');$q->execute([(int)$_GET['edit']]);$edit=$q->fetch();}
$search=trim($_GET['q']??'');$perPage=(int)($_GET['per_page']??25);if(!in_array($perPage,[10,25,50,100],true))$perPage=25;$page=max(1,(int)($_GET['page']??1));$where='';$params=[];
if($search!==''){$where='WHERE p.name LIKE ? OR p.code LIKE ? OR p.barcode LIKE ?';$like='%'.$search.'%';$params=[$like,$like,$like];}
$count=$pdo->prepare('SELECT COUNT(*) FROM products p '.$where);$count->execute($params);$total=(int)$count->fetchColumn();$pages=max(1,(int)ceil($total/$perPage));$page=min($page,$pages);$offset=($page-1)*$perPage;
$sql='SELECT p.*,c.name category,pc.name parent_category FROM products p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN categories pc ON pc.id=c.parent_id '.$where.' ORDER BY p.active DESC,p.name LIMIT '.$perPage.' OFFSET '.$offset;$st=$pdo->prepare($sql);$st->execute($params);$rows=$st->fetchAll();
?>
<div class="grid grid-2">
<div class="card">
<b><?= $edit?'Edit':'Tambah' ?> Produk / Jasa</b><div class="muted" style="margin-top:5px">Produk menggunakan stok. Jasa tidak mengurangi stok saat transaksi.</div>
<form method="post" style="margin-top:14px"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="id" value="<?=$edit['id']??0?>">
<div class="form-grid">
<div class="form-group"><label>Kode Produk / Jasa</label><input class="form-control" name="code" required value="<?=e($edit['code']??'')?>"></div>
<div class="form-group"><label>Barcode 1D</label><input class="form-control" name="barcode" value="<?=e($edit['barcode']??'')?>" placeholder="Kosongkan untuk dibuat otomatis"></div>
<div class="form-group"><label>Nama</label><input class="form-control" name="name" required value="<?=e($edit['name']??'')?>"></div>
<div class="form-group"><label>Jenis Item</label><select class="form-control" name="item_type"><option value="PRODUCT" <?=($edit['item_type']??'PRODUCT')==='PRODUCT'?'selected':''?>>Produk / Stok</option><option value="SERVICE" <?=($edit['item_type']??'')==='SERVICE'?'selected':''?>>Jasa / Tanpa Stok</option></select></div>
<div class="form-group"><label>Kategori</label><select class="form-control" name="category_id"><option value="">-</option><?php foreach($cats as $c): ?><option value="<?=$c['id']?>" <?=($edit['category_id']??'')==$c['id']?'selected':''?>><?=e($c['parent_id']?'↳ '.$c['name'].' ('.$c['parent_name'].')':$c['name'])?></option><?php endforeach; ?></select></div>
<div class="form-group"><label>Satuan</label><input class="form-control" name="unit" value="<?=e($edit['unit']??'pcs')?>"></div>
<div class="form-group"><label>Harga Jual</label><input class="form-control" type="number" name="price" min="0" value="<?=e((string)($edit['price']??0))?>"></div>
<div class="form-group"><label>Harga Modal</label><input class="form-control" type="number" name="cost_price" min="0" value="<?=e((string)($edit['cost_price']??0))?>"></div>
<div class="form-group"><label>Stok Minimum</label><input class="form-control" type="number" name="min_stock" min="0" step="0.01" value="<?=e((string)($edit['min_stock']??0))?>"></div>
<?php if(!$edit): ?><div class="form-group"><label>Stok Awal</label><input class="form-control" type="number" name="initial_stock" min="0" step="0.01" value="0"><small class="muted">Hanya untuk produk.</small></div><?php else: ?><div class="form-group"><label>Stok Saat Ini</label><input class="form-control" value="<?=e((string)$edit['stock'])?> <?=e($edit['unit'])?>" readonly><small class="muted">Gunakan menu Persediaan untuk menambah/menyesuaikan stok.</small></div><?php endif; ?>
</div>
<label style="display:block;margin-top:12px"><input type="checkbox" name="active" <?=(!$edit||$edit['active'])?'checked':''?>> Aktif</label>
<button class="btn" style="margin-top:12px">Simpan</button><?php if($edit):?><a class="btn secondary" href="<?=BASE_URL?>/master/produk.php">Batal</a><?php endif;?><?php if($edit && !empty($edit['barcode'])):?><a class="btn secondary" target="_blank" style="margin-top:12px" href="<?=BASE_URL?>/barcode/label.php?id=<?=$edit['id']?>">🏷️ Cetak Barcode</a><?php endif;?>
</form></div>
<div class="card product-list-card"><div class="toolbar product-list-head"><div><b>Daftar Produk & Jasa</b><div class="muted">Stok, minimum stok, dan jenis item ditampilkan di sini.</div></div></div>
<div class="product-tools-under-add"><a class="btn secondary" href="<?=BASE_URL?>/master/import_produk.php">⬆ Import Excel</a><a class="btn secondary" href="<?=BASE_URL?>/master/export_produk.php">⬇ Export Excel</a><?php if(has_permission('stock.manage')):?><a class="btn secondary" href="<?=BASE_URL?>/master/stok.php">📦 Kelola Stok</a><?php endif;?></div>
<form method="get" class="product-filter"><input class="form-control" name="q" value="<?=e($search)?>" placeholder="Cari nama / kode / barcode..."><select class="form-control" name="per_page" onchange="this.form.submit()"><option value="10" <?=$perPage===10?'selected':''?>>10 / halaman</option><option value="25" <?=$perPage===25?'selected':''?>>25 / halaman</option><option value="50" <?=$perPage===50?'selected':''?>>50 / halaman</option><option value="100" <?=$perPage===100?'selected':''?>>100 / halaman</option></select><button class="btn secondary">Cari</button><?php if($search!==''): ?><a class="btn secondary" href="<?=BASE_URL?>/master/produk.php">Reset</a><?php endif; ?></form>
<div class="product-count muted">Menampilkan <?= $total?($offset+1):0 ?>–<?=min($offset+$perPage,$total)?> dari <?=$total?> produk/jasa</div>
<div class="table-wrap"><table class="table"><thead><tr><th>Kode</th><th>Produk / Jasa</th><th>Kategori</th><th>Harga Jual</th><th>Stok</th><th>Minimum</th><th>Status</th><th>Aksi</th></tr></thead><tbody><?php if(!$rows): ?><tr><td colspan="8" class="muted" style="text-align:center;padding:30px">Belum ada data produk.</td></tr><?php endif; ?>
<?php foreach($rows as $r):$low=$r['item_type']==='PRODUCT' && (float)$r['stock']<=(float)$r['min_stock']; ?><tr><td><?=e($r['code'])?><div class="muted"><code><?=e($r['barcode']??'-')?></code></div></td><td><strong><?=e($r['name'])?></strong><div class="muted"><?=e($r['item_type']==='SERVICE'?'Jasa':'Produk')?> · <?=e($r['unit'])?></div></td><td><?=e($r['parent_category']?$r['parent_category'].' › '.$r['category']:($r['category']??'-'))?></td><td><?=rupiah($r['price'])?></td><td><?php if($r['item_type']==='SERVICE'): ?><span class="badge blue">Tanpa stok</span><?php else: ?><strong class="<?=$low?'stock-low':''?>"><?=e(rtrim(rtrim(number_format((float)$r['stock'],2,'.',''),'0'),'.'))?></strong> <?=e($r['unit'])?><?php endif;?></td><td><?=$r['item_type']==='SERVICE'?'-':e(rtrim(rtrim(number_format((float)$r['min_stock'],2,'.',''),'0'),'.')).' '.e($r['unit'])?></td><td><span class="badge <?=$r['active']?'green':'red'?>"><?=$r['active']?'Aktif':'Nonaktif'?></span></td><td><a class="btn secondary sm" href="?edit=<?=$r['id']?>">Edit</a><?php if($r['barcode']):?><a class="btn secondary sm" target="_blank" href="<?=BASE_URL?>/barcode/label.php?id=<?=$r['id']?>">🏷️</a><?php endif;?></td></tr><?php endforeach;?></tbody></table></div>
<?php if($pages>1): ?><div class="pagination"><?php for($i=1;$i<=$pages;$i++): ?><a class="page-link <?=$i===$page?'active':''?>" href="?<?=http_build_query(['q'=>$search,'per_page'=>$perPage,'page'=>$i])?>"><?=$i?></a><?php endfor; ?></div><?php endif; ?></div></div>
<?php require __DIR__.'/../includes/footer.php'; ?>
