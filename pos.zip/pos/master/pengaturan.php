<?php
$title='Pengaturan Toko & Struk'; require_once __DIR__.'/../includes/header.php';require_permission('settings.manage'); require_admin();
$pdo=db();
if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_check();
    foreach(['store_name','store_address','store_phone','receipt_footer','receipt_width','order_prefix','receipt_printer'] as $k){
        $q=$pdo->prepare('INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)');
        $q->execute([$k,trim($_POST[$k]??'')]);
    }
    if(isset($_POST['remove_logo'])){
        $pdo->prepare('UPDATE settings SET setting_value="" WHERE setting_key="store_logo"')->execute();
        flash('success','Logo dihapus.');
    } elseif(isset($_FILES['store_logo']) && $_FILES['store_logo']['error']===UPLOAD_ERR_OK){
        $f=$_FILES['store_logo']; $ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION));
        if($f['size']>1048576) flash('danger','Logo maksimal 1 MB.');
        elseif(!in_array($ext,['jpg','jpeg','png','webp'],true)) flash('danger','Format logo harus JPG, PNG, atau WEBP.');
        else{
            $dir=__DIR__.'/../uploads'; if(!is_dir($dir)) mkdir($dir,0775,true);
            $name='logo_'.bin2hex(random_bytes(6)).'.'.$ext;
            if(move_uploaded_file($f['tmp_name'],$dir.'/'.$name)){
                $pdo->prepare('INSERT INTO settings(setting_key,setting_value) VALUES("store_logo",?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)')->execute(['uploads/'.$name]);
                flash('success','Logo berhasil diupload.');
            }
        }
    } else flash('success','Pengaturan disimpan.');
    redirect('/master/pengaturan.php');
}
?>
<div class="grid grid-2"><div class="card"><b>Identitas Toko</b><form method="post" enctype="multipart/form-data" style="margin-top:14px"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><div class="form-group"><label>Nama Toko / Percetakan</label><input class="form-control" name="store_name" value="<?=e(setting('store_name'))?>" required></div><div class="form-group" style="margin-top:10px"><label>Alamat</label><textarea class="form-control" name="store_address" rows="2"><?=e(setting('store_address'))?></textarea></div><div class="form-group" style="margin-top:10px"><label>Telepon / WhatsApp</label><input class="form-control" name="store_phone" value="<?=e(setting('store_phone'))?>"></div><div class="form-group" style="margin-top:10px"><label>Logo</label><div class="dropzone"><?php if(setting('store_logo')):?><img class="preview-logo" src="<?=BASE_URL.'/'.e(setting('store_logo'))?>"><br><button class="btn danger sm" name="remove_logo" value="1" style="margin-top:8px">Hapus Logo</button><?php else:?><div class="muted">Belum ada logo</div><?php endif;?><input class="form-control" type="file" name="store_logo" accept="image/png,image/jpeg,image/webp" style="margin-top:10px"></div></div><div class="form-grid" style="margin-top:10px"><div class="form-group"><label>Printer Struk</label><input class="form-control" name="receipt_printer" value="<?=e(setting('receipt_printer','Struk'))?>" required><small class="muted">Nama printer Windows. Untuk printer Anda gunakan <b>Struk</b>.</small></div><div class="form-group"><label>Lebar Struk</label><select class="form-control" name="receipt_width"><option value="80" <?=setting('receipt_width','80')==='80'?'selected':''?>>80 mm</option><option value="58" <?=setting('receipt_width')==='58'?'selected':''?>>58 mm</option></select></div><div class="form-group"><label>Prefix Order</label><input class="form-control" name="order_prefix" value="<?=e(setting('order_prefix','ORD'))?>"></div></div><div class="form-group" style="margin-top:10px"><label>Footer Struk</label><textarea class="form-control" name="receipt_footer" rows="3"><?=e(setting('receipt_footer'))?></textarea></div><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px"><button class="btn" type="submit">Simpan Pengaturan</button><button class="btn secondary" type="button" onclick="testPrinter()">🖨️ Test Print</button></div></form></div><div class="card"><b>Preview Struk</b><div class="muted" style="margin-bottom:10px">Preview identitas yang akan digunakan printer thermal.</div><div style="width:<?=setting('receipt_width','80')?>mm;max-width:100%;margin:auto;border:1px dashed #bbb;padding:10px;font-family:monospace;text-align:center;font-size:12px;background:#fff"><?php if(setting('store_logo')):?><img src="<?=BASE_URL.'/'.e(setting('store_logo'))?>" style="max-width:100px;max-height:55px"><br><?php endif;?><b><?=e(setting('store_name'))?></b><br><?=nl2br(e(setting('store_address')))?><br><?=e(setting('store_phone'))?><hr style="border:0;border-top:1px dashed #555"><div style="text-align:left">INV-20261007-1234<br>Print A4 Hitam Putih x 2<br>Rp 1.000<br>Fotocopy x 5<br>Rp 2.500</div><hr style="border:0;border-top:1px dashed #555"><b>TOTAL Rp 3.500</b><br><br><?=e(setting('receipt_footer'))?></div></div></div>
<script>async function testPrinter(){try{if(!window.POSPrinter)throw new Error('Modul QZ Tray belum tersedia.');await window.POSPrinter.testPrint();alert('Test print berhasil dikirim ke printer Struk.');}catch(e){alert('Test print gagal: '+e.message);}}</script>
<?php require __DIR__.'/../includes/footer.php'; ?>
