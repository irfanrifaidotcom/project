# QZ Tray + Epson TM-T82X-II

POS Percetakan sekarang mendukung cetak struk langsung menggunakan QZ Tray + ESC/POS.

## 1. Printer Windows

Rename printer Windows menjadi:

`Struk`

## 2. Install QZ Tray

Install QZ Tray pada komputer kasir dan pastikan aplikasinya sedang berjalan.

## 3. qz-tray.js

Untuk penggunaan lokal tanpa CDN, salin file berikut dari instalasi QZ Tray:

`C:\Program Files\QZ Tray\demo\js\qz-tray.js`

ke:

`assets/js/qz-tray.js`

Versi aplikasi juga memiliki fallback CDN `qz-tray@2.2.5` jika file lokal tidak tersedia dan komputer kasir memiliki internet.

## 4. Test printer

Buka:

`Master > Pengaturan`

Isi:

- Printer Struk: `Struk`
- Lebar Struk: `80 mm`

Klik **Test Print**.

## 5. Alur kasir

`Simpan & Cetak Struk` akan:

1. Menyimpan transaksi melalui AJAX.
2. Mengambil data transaksi.
3. Membuat perintah ESC/POS.
4. Mengirim langsung ke printer `Struk`.
5. Tidak membuka PDF.
6. Tidak membuka tab struk.
7. Mereset keranjang dan field kasir.
8. Mengembalikan fokus ke Scan Barcode 1D.

## Catatan

QZ Tray tanpa certificate signing dapat menampilkan permintaan izin/trust. Untuk penggunaan production yang benar-benar silent, konfigurasi certificate/signing QZ perlu dilakukan.
