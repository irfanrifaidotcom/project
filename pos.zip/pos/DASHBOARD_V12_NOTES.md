# POS Percetakan v12 — Dashboard Modern

Perbaikan utama:

- Dashboard didesain ulang dengan layout modern, responsive, KPI cards, hero section, quick actions, grafik penjualan, transaksi terbaru, dan produk terlaris.
- CSS dashboard dipisahkan ke `assets/css/dashboard.css` agar lebih mudah dirawat.
- `includes/header.php` sekarang mendukung `$page_css` untuk stylesheet per halaman.
- CSS global dan CSS halaman menggunakan `filemtime()` sebagai cache-busting, sehingga perubahan CSS tidak tertahan cache browser.
- Semua stylesheet menggunakan `BASE_URL` `/pos`, sehingga path sesuai instalasi `C:\xampp\htdocs\pos`.
- Header/topbar diperbaiki agar lebih informatif dan responsive.
- Tidak mengubah struktur database.

## Instalasi

Ekstrak isi ZIP ke:

`C:\xampp\htdocs\pos`

Jika menimpa instalasi lama, backup folder `pos` terlebih dahulu.

Akses:

`http://localhost/pos/`

Hard refresh browser setelah update (`Ctrl + F5`).
