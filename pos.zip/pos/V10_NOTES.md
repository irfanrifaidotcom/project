# POS Percetakan v10
Kategori sekarang mendukung parent/subkategori melalui parent_id.
Jalankan database/upgrade_v10_kategori.sql.
Template Excel: assets/template_produk_v10.xlsx
Kolom import: kode, barcode, nama, kategori_induk, kategori, satuan, harga_jual, harga_modal, aktif.
