<?php
declare(strict_types=1);
const APP_NAME='POS Percetakan'; const APP_VERSION='2.2.0'; define('BASE_URL','/pos');
const DB_HOST='127.0.0.1'; const DB_PORT='3306'; const DB_NAME='pos_percetakan'; const DB_USER='root'; const DB_PASS=''; const CURRENCY='Rp';
date_default_timezone_set('Asia/Jakarta'); if(session_status()===PHP_SESSION_NONE) session_start();
function db():PDO{static $p=null;if($p instanceof PDO)return $p;$p=new PDO('mysql:host='.DB_HOST.';port='.DB_PORT.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);return $p;}
function e(?string $v):string{return htmlspecialchars($v??'',ENT_QUOTES,'UTF-8');} function rupiah(float|int $n):string{return CURRENCY.' '.number_format((float)$n,0,',','.');}
function redirect(string $p):never{header('Location: '.BASE_URL.$p);exit;} function flash(string $t,string $m):void{$_SESSION['flash'][]=[$t,$m];} function flashes():array{$x=$_SESSION['flash']??[];unset($_SESSION['flash']);return $x;}
function require_login():void{
    if(empty($_SESSION['user']) || empty($_SESSION['user']['id'])){
        $_SESSION['user']=null;
        redirect('/auth/login.php');
    }
    try{
        $q=db()->prepare('SELECT id,username,name,role,active FROM users WHERE id=? LIMIT 1');
        $q->execute([(int)$_SESSION['user']['id']]);
        $u=$q->fetch();
        if(!$u || !(int)$u['active']){
            unset($_SESSION['user']);
            redirect('/auth/login.php');
        }
        $_SESSION['user']=[
            'id'=>(int)$u['id'],
            'username'=>$u['username'],
            'name'=>$u['name'],
            'role'=>$u['role']
        ];
    }catch(Throwable $e){
        unset($_SESSION['user']);
        redirect('/auth/login.php');
    }
} function require_admin():void{require_login();if(($_SESSION['user']['role']??'')!=='admin'){http_response_code(403);exit('Akses ditolak.');}}
function has_permission(string $key):bool{
    $u=current_user(); if(!$u) return false;
    if(($u['role']??'')==='admin') return true;
    try{
        $q=db()->prepare('SELECT 1 FROM permissions p LEFT JOIN role_permissions rp ON rp.permission_id=p.id AND rp.role=? LEFT JOIN user_permissions up ON up.permission_id=p.id AND up.user_id=? WHERE p.permission_key=? AND COALESCE(up.allowed, IF(rp.permission_id IS NULL,0,1))=1 LIMIT 1');
        $q->execute([$u['role'],(int)$u['id'],$key]); return (bool)$q->fetchColumn();
    }catch(Throwable $e){ return false; }
}
function require_permission(string $key):void{require_login();if(!has_permission($key)){http_response_code(403);exit('Akses ditolak. Anda tidak memiliki hak akses untuk halaman ini.');}}
function activity_log(string $action,string $description=''):void{try{$u=current_user();db()->prepare('INSERT INTO user_activity_logs(user_id,action,description,ip_address,user_agent) VALUES(?,?,?,?,?)')->execute([$u['id']??null,$action,$description,$_SERVER['REMOTE_ADDR']??null,substr($_SERVER['HTTP_USER_AGENT']??'',0,255)]);}catch(Throwable $e){}}
function user_permissions(int $userId):array{try{$q=db()->prepare('SELECT p.permission_key,up.allowed FROM user_permissions up JOIN permissions p ON p.id=up.permission_id WHERE up.user_id=?');$q->execute([$userId]);$out=[];foreach($q as $r)$out[$r['permission_key']]=(int)$r['allowed'];return $out;}catch(Throwable $e){return [];}}
function current_user():array{return $_SESSION['user']??[];} function csrf_token():string{if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));return $_SESSION['csrf'];} function csrf_check():void{if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')){http_response_code(419);exit('CSRF token tidak valid.');}}
function setting(string $key,string $default=''):string{static $c=[];if(array_key_exists($key,$c))return $c[$key];try{$q=db()->prepare('SELECT setting_value FROM settings WHERE setting_key=?');$q->execute([$key]);$v=$q->fetchColumn();}catch(Throwable $e){$v=false;}return $c[$key]=$v===false?$default:(string)$v;}
function invoice_no():string{return 'INV-'.date('Ymd-His').'-'.random_int(10,99);} function clean_money(mixed $v):float{return max(0,(float)str_replace([',','.',' '],['','',''],(string)$v));}
