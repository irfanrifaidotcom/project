# Database POS Percetakan

Mulai versi ini database menggunakan **satu file SQL utama**:

`database/pos_percetakan.sql`

File tersebut berisi schema lengkap, user, permission, kategori bertingkat, pelanggan default, produk/jasa awal, barcode dan pengaturan toko.

File SQL upgrade versi lama sudah dihapus agar instalasi tidak membingungkan dan tidak ada seed kategori lama yang ikut terpakai.

> **Penting:** SQL utama melakukan DROP TABLE dan membuat ulang seluruh tabel. Backup database lama terlebih dahulu jika masih memiliki transaksi/data penting.
