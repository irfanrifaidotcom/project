<?php $title='Kasir / Order Percetakan'; require_once __DIR__.'/../includes/header.php';require_permission('sales.create'); $pdo=db(); $products=$pdo->query("SELECT p.*,c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.active=1 ORDER BY p.name")->fetchAll(); $customers=$pdo->query('SELECT * FROM customers ORDER BY name')->fetchAll(); $cats=$pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll(); ?>
<form method="post" action="<?=BASE_URL?>/api/sale.php" id="saleForm"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="items" id="items"><div class="pos-layout"><div>
<div class="card" style="margin-bottom:16px"><div class="toolbar" style="margin-bottom:8px"><div><b>🔎 Scan Barcode 1D</b><div class="muted">Arahkan scanner ke barcode produk. Scanner USB/Bluetooth akan bekerja seperti keyboard.</div></div><span class="badge blue">CODE128</span></div><div class="scan-box"><input id="barcodeInput" class="form-control" autocomplete="off" placeholder="Scan barcode di sini lalu tekan ENTER" autofocus><button type="button" class="btn secondary" id="scanFocus">Fokus</button></div><div id="scanStatus" class="scan-status muted">Scanner siap.</div></div>
<div class="card"><div class="toolbar"><div><b>Daftar Produk & Jasa</b><div class="muted">Klik item atau scan barcode untuk memasukkan ke keranjang.</div></div><input id="search" class="form-control search" placeholder="Cari produk / kode / barcode..."></div><div class="toolbar"><div class="actions"><button type="button" class="btn secondary sm filter" data-cat="">Semua</button><?php foreach($cats as $c):?><button type="button" class="btn secondary sm filter" data-cat="<?=e($c['name'])?>"><?=e($c['name'])?></button><?php endforeach;?></div></div><div class="product-grid" id="products"><?php foreach($products as $p):?><div class="product-card" data-id="<?=$p['id']?>" data-name="<?=e($p['name'])?>" data-price="<?=$p['price']?>" data-unit="<?=e($p['unit'])?>" data-barcode="<?=e($p['barcode']??'')?>" data-cat="<?=e($p['category']??'')?>" data-search="<?=e(strtolower($p['name'].' '.$p['code'].' '.($p['barcode']??'')))?>"><b><?=e($p['name'])?></b><span><?=e($p['code'])?> · <?=e($p['unit'])?></span><div class="barcode-mini"><?=e($p['barcode']??'-')?></div><div style="margin-top:7px;font-weight:800;color:#087786"><?=rupiah($p['price'])?></div></div><?php endforeach;?></div></div></div>
<div class="card cart"><div class="toolbar"><div><b>Keranjang</b><div class="muted" id="itemCount">0 item</div></div><button type="button" class="btn danger sm" id="clearCart">Kosongkan</button></div><div class="cart-list" id="cart"></div><div class="summary"><div><span>Subtotal</span><b id="subtotal">Rp 0</b></div><div><span>Diskon</span><input class="form-control" style="width:130px;text-align:right" type="number" min="0" step="500" name="discount" id="discount" value="0"></div><div class="grand"><span>Total</span><b id="grand">Rp 0</b></div></div><hr style="border:0;border-top:1px solid #edf0f4;margin:16px 0"><div class="form-group"><label>Pelanggan</label><select class="form-control" name="customer_id"><option value="">Pelanggan Umum</option><?php foreach($customers as $c):?><option value="<?=$c['id']?>"><?=e($c['name'])?><?= $c['phone']?' · '.e($c['phone']):''?></option><?php endforeach;?></select></div><div class="form-grid" style="margin-top:12px"><div class="form-group"><label>Jenis Order</label><select class="form-control" name="order_type"><option>Kasir</option><option>Print</option><option>Fotocopy</option><option>Banner</option><option>Stiker</option><option>Jilid</option><option>Desain</option><option>Custom</option></select></div><div class="form-group"><label>Selesai</label><input class="form-control" type="date" name="due_date" value="<?=date('Y-m-d')?>"></div><div class="form-group full"><label>Catatan / Detail Pekerjaan</label><textarea class="form-control" name="job_description" id="job_description" rows="2" placeholder="Ukuran, bahan, warna, finishing, dll."></textarea></div><div class="form-group"><label>Bayar / DP</label><input class="form-control" type="number" name="paid" id="paid" min="0" step="500" value="0"></div><div class="form-group"><label>Metode</label><select class="form-control" name="payment_method"><option>CASH</option><option>QRIS</option><option>DEBIT</option><option>TRANSFER</option></select></div></div><div class="summary"><div><span>Sisa</span><b id="remaining">Rp 0</b></div><div><span>Kembalian</span><b id="change">Rp 0</b></div></div><button class="btn success" style="width:100%;margin-top:14px">🖨️ Simpan & Cetak Struk</button></div></div></form>
<script>
const cart=[];
const money=n=>'Rp '+Number(n||0).toLocaleString('id-ID');
const esc=s=>String(s??'').replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[m]));
function addProduct(p){let x=cart.find(i=>i.id==p.id);if(x)x.qty++;else cart.push({id:Number(p.id),name:p.name,price:Number(p.price),unit:p.unit,barcode:p.barcode||'',qty:1});render();}
function render(){const el=document.getElementById('cart');el.innerHTML='';let sub=0,count=0;cart.forEach((x,i)=>{x.total=x.qty*x.price;sub+=x.total;count+=x.qty;el.insertAdjacentHTML('beforeend',`<div class="cart-row"><div><b>${esc(x.name)}</b><div class="muted">${money(x.price)} / ${esc(x.unit)}</div><div class="barcode-mini">${esc(x.barcode)}</div></div><input class="qty" type="number" min="0.01" step="0.01" value="${x.qty}" onchange="cart[${i}].qty=Math.max(.01,parseFloat(this.value)||1);render()"><b>${money(x.total)}</b><button type="button" onclick="cart.splice(${i},1);render()" style="border:0;background:none;color:#d33">×</button></div>`)});const dis=parseFloat(document.getElementById('discount').value)||0;const total=Math.max(0,sub-dis);const paid=parseFloat(document.getElementById('paid').value)||0;document.getElementById('subtotal').textContent=money(sub);document.getElementById('grand').textContent=money(total);document.getElementById('remaining').textContent=money(Math.max(0,total-paid));document.getElementById('change').textContent=money(Math.max(0,paid-total));document.getElementById('itemCount').textContent=count+' item';document.getElementById('items').value=JSON.stringify(cart)}
async function scanBarcode(){const input=document.getElementById('barcodeInput'),status=document.getElementById('scanStatus'),value=input.value.trim();if(!value)return;status.className='scan-status muted';status.textContent='Mencari barcode '+value+'...';try{const r=await fetch('<?=BASE_URL?>/api/barcode.php?barcode='+encodeURIComponent(value),{headers:{'Accept':'application/json'}});const d=await r.json();if(!d.ok)throw new Error(d.message);addProduct(d.product);status.className='scan-status scan-ok';status.textContent='✓ '+d.product.name+' ditambahkan ke keranjang.';input.value='';input.focus();}catch(e){status.className='scan-status scan-error';status.textContent='✕ '+e.message;input.select();}}
document.querySelectorAll('.product-card').forEach(c=>c.onclick=()=>addProduct({id:c.dataset.id,name:c.dataset.name,price:c.dataset.price,unit:c.dataset.unit,barcode:c.dataset.barcode}));
document.getElementById('barcodeInput').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();scanBarcode()}});document.getElementById('scanFocus').onclick=()=>document.getElementById('barcodeInput').focus();
document.getElementById('discount').oninput=render;document.getElementById('paid').oninput=render;document.getElementById('clearCart').onclick=()=>{cart.length=0;render();document.getElementById('barcodeInput').focus()};document.getElementById('search').oninput=e=>{const q=e.target.value.toLowerCase();document.querySelectorAll('.product-card').forEach(c=>c.style.display=c.dataset.search.includes(q)?'block':'none')};document.querySelectorAll('.filter').forEach(b=>b.onclick=()=>{const cat=b.dataset.cat;document.querySelectorAll('.product-card').forEach(c=>c.style.display=!cat||c.dataset.cat===cat?'block':'none')});
let saleSubmitting=false;
function setSubmitState(loading){const btn=document.querySelector('#saleForm button[type=submit]');if(!btn)return;btn.disabled=loading;btn.innerHTML=loading?'⏳ Menyimpan & mencetak...':'🖨️ Simpan & Cetak Struk';}
function resetSaleForm(){
 cart.length=0;
 document.getElementById('discount').value='0';
 document.getElementById('paid').value='0';
 document.getElementById('job_description').value='';
 document.querySelector('[name=customer_id]').value='';
 document.querySelector('[name=order_type]').value='Kasir';
 document.querySelector('[name=due_date]').value='<?=date('Y-m-d')?>';
 document.querySelector('[name=payment_method]').value='CASH';
 document.getElementById('barcodeInput').value='';
 document.getElementById('search').value='';
 document.querySelectorAll('.product-card').forEach(c=>c.style.display='block');
 document.querySelectorAll('.filter').forEach(b=>b.classList.toggle('active',b.dataset.cat===''));
 document.getElementById('scanStatus').className='scan-status muted';
 document.getElementById('scanStatus').textContent='Scanner siap.';
 render();
 saleSubmitting=false;
 setSubmitState(false);
 setTimeout(()=>document.getElementById('barcodeInput').focus(),50);
}
async function submitSale(){
 if(saleSubmitting)return;
 if(!cart.length){alert('Keranjang masih kosong.');document.getElementById('barcodeInput').focus();return;}
 saleSubmitting=true;setSubmitState(true);
 const form=document.getElementById('saleForm');
 const data=new FormData(form);data.set('items',JSON.stringify(cart));data.set('response','json');
 try{
   const r=await fetch(form.action,{method:'POST',body:data,headers:{Accept:'application/json'}});
   const d=await r.json();
   if(!r.ok||!d.ok)throw new Error(d.message||'Transaksi gagal disimpan.');
   try{
     document.getElementById('scanStatus').className='scan-status muted';
     document.getElementById('scanStatus').textContent='Transaksi tersimpan. Mengirim struk ke printer...';
     if(!window.POSPrinter)throw new Error('Modul printer QZ Tray belum tersedia.');
     await window.POSPrinter.printSale(d.sale_id);
     document.getElementById('scanStatus').className='scan-status scan-ok';
     document.getElementById('scanStatus').textContent='✓ '+d.invoice_no+' berhasil dicetak ke printer Struk.';
   }catch(printError){
     document.getElementById('scanStatus').className='scan-status scan-error';
     document.getElementById('scanStatus').textContent='Transaksi tersimpan, tetapi printer gagal: '+printError.message;
     alert('Transaksi tersimpan dengan nomor '+d.invoice_no+' tetapi struk belum tercetak.\n\n'+printError.message);
   }
   resetSaleForm();
 }catch(e){
   saleSubmitting=false;setSubmitState(false);
   document.getElementById('scanStatus').className='scan-status scan-error';
   document.getElementById('scanStatus').textContent='✕ '+e.message;
   alert(e.message);
   document.getElementById('barcodeInput').focus();
 }
}
document.getElementById('saleForm').addEventListener('submit',e=>{e.preventDefault();submitSale();});
// Selalu mulai dalam kondisi default dan fokus scanner.
resetSaleForm();
</script><?php require __DIR__.'/../includes/footer.php'; ?>
