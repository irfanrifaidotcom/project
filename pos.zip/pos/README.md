# POS Percetakan v2.0

Aplikasi POS / kasir percetakan menggunakan **PHP Native + MySQL/MariaDB**, tanpa framework backend.

## Fitur
- Dashboard omzet dan transaksi
- Kasir / order percetakan
- Produk & jasa
- Kategori
- Pelanggan
- Pesanan dan status pekerjaan: BARU, DIPROSES, SELESAI, DIAMBIL, BATAL
- Pembayaran DP / pelunasan bertahap
- Metode CASH, QRIS, DEBIT, TRANSFER
- Catatan pekerjaan: ukuran, bahan, finishing, dll.
- Laporan penjualan berdasarkan periode
- Pengeluaran
- Pengaturan nama toko, alamat, telepon, footer struk
- Upload logo toko
- Manajemen pengguna Admin / Kasir
- Struk thermal 58/80 mm dengan CSS print khusus Epson TM
- PDO prepared statements + CSRF

## Instalasi baru
1. Extract ke `C:\xampp\htdocs\pos-percetakan`.
2. Jalankan Apache dan MySQL.
3. Import `database/schema.sql` melalui phpMyAdmin.
4. Sesuaikan DB di `config/config.php` bila perlu.
5. Buka `http://localhost/pos-percetakan/`.
6. Login awal: `admin` / `password`.
7. Segera buat/ganti akun admin setelah login.

## Upgrade dari v3
Backup database terlebih dahulu. Import `database/upgrade_v3.sql`, lalu ganti folder aplikasi dengan versi ini. Jika konfigurasi DB berbeda, sesuaikan `config/config.php`.

## Epson TM
- Untuk roll 80 mm pilih paper width 80 mm pada driver Epson TM.
- Untuk 58 mm ubah pengaturan toko menjadi 58 mm.
- Saat browser print, gunakan Scale 100% / Actual Size dan jangan Fit to Page.
- Untuk cetak tanpa dialog browser, diperlukan integrasi ESC/POS / printer service di komputer kasir. Versi ini memakai browser print agar tidak membutuhkan software tambahan.

## Struktur utama
`transaksi/penjualan.php` = kasir
`transaksi/pesanan.php` = workflow order
`pelanggan/index.php` = pelanggan
`master/produk.php` = produk/jasa
`master/pengaturan.php` = toko & logo
`print/receipt.php` = struk thermal
`laporan/penjualan.php` = laporan
`laporan/pengeluaran.php` = pengeluaran

## Manajemen User v6
- Role: Administrator, Manager, Kasir, Produksi
- Hak akses granular per modul
- Override permission per user
- Aktif/nonaktif akun
- Ganti password oleh admin
- Profil & ganti password sendiri
- Audit log login/logout dan perubahan user
- Proteksi halaman menggunakan permission server-side

Upgrade database: import `database/upgrade_v5_users.sql` setelah database v5 aktif.


## v7 fixes
- Fixed fatal error in transaksi/penjualan.php caused by chained assignment `$products=$pdo=db()->query(...)->fetchAll()`.
- BASE_URL is now detected automatically from the installed folder, so CSS/assets work when the application is installed as `htdocs/pos`, `htdocs/pos-percetakan`, etc.


## Cetak Struk
Setelah transaksi berhasil, halaman struk dibuka sebagai halaman HTML thermal (bukan PDF) dan otomatis menjalankan dialog cetak browser. Setelah proses cetak selesai, jendela struk mencoba menutup otomatis dan halaman kasir dikosongkan kembali. Cetak diam/silent tanpa dialog browser membutuhkan solusi lokal seperti QZ Tray atau integrasi Epson ePOS; browser biasa tidak mengizinkan PHP melakukan silent print langsung ke printer.
