</div></main>
<script>window.POS_BASE_URL=<?=json_encode(BASE_URL)?>;window.POS_PRINTER_NAME=<?=json_encode(setting('receipt_printer','Struk'))?>;</script>
<script src="<?=BASE_URL?>/assets/js/qz-tray.js" onerror="var s=document.createElement('script');s.src='https://cdn.jsdelivr.net/npm/qz-tray@2.2.5/qz-tray.js';document.head.appendChild(s);"></script>
<script src="<?=BASE_URL?>/assets/js/qz-pos.js?v=<?php $qzJs=__DIR__ . '/../assets/js/qz-pos.js'; echo rawurlencode(is_file($qzJs)?(string)filemtime($qzJs):APP_VERSION); ?>"></script>
<script src="<?=BASE_URL?>/assets/js/app.js?v=<?php $appJs=__DIR__.'/../assets/js/app.js'; echo rawurlencode(is_file($appJs)?(string)filemtime($appJs):APP_VERSION); ?>"></script>
</body></html>
