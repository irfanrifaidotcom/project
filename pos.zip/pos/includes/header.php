<?php
require_once __DIR__.'/../config/config.php';
require_login();
$user = current_user();
$currentPath = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?? '';
$basePath = rtrim(BASE_URL, '/');
if ($currentPath === $basePath || $currentPath === $basePath . '/') {
    $currentPath .= 'index.php';
}
$pageCss = $page_css ?? [];
if (!is_array($pageCss)) $pageCss = [$pageCss];
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="theme-color" content="#18b7c9">
    <title><?=e($title ?? APP_NAME)?></title>
    <?php $appCssPath = __DIR__ . '/../assets/css/app.css'; $appCssVersion = is_file($appCssPath) ? (string)filemtime($appCssPath) : APP_VERSION; ?><link rel="stylesheet" href="<?=BASE_URL?>/assets/css/app.css?v=<?=rawurlencode($appCssVersion)?>">
    <?php foreach ($pageCss as $css): ?>
        <?php
        $cssPath = __DIR__ . '/../assets/css/' . basename((string)$css);
        $cssVersion = is_file($cssPath) ? (string)filemtime($cssPath) : APP_VERSION;
        ?>
        <link rel="stylesheet" href="<?=BASE_URL?>/assets/css/<?=e(basename((string)$css))?>?v=<?=rawurlencode($cssVersion)?>">
    <?php endforeach; ?>
</head>
<body>
<aside class="sidebar">
    <div class="brand">
        <div class="brand-img">
            <?php $logo = setting('store_logo'); ?>
            <?php if ($logo): ?>
                <img src="<?=BASE_URL.'/'.e($logo)?>" alt="Logo">
            <?php else: ?>🖨️<?php endif; ?>
        </div>
        <div>
            <b><?=e(setting('store_name', APP_NAME))?></b>
            <small>POS Percetakan</small>
        </div>
    </div>

    <div class="side-overlay" onclick="document.body.classList.remove('sidebar-open')"></div>

    <nav>
        <?php
        $nav = [
            ['dashboard.view','index.php','🏠 Dashboard'],
            ['sales.create','transaksi/penjualan.php','🧾 Kasir / Order'],
            ['orders.manage','transaksi/pesanan.php','📋 Pesanan'],
            ['customers.manage','pelanggan/index.php','👥 Pelanggan'],
            ['products.manage','master/produk.php','📦 Produk & Jasa'],
            ['stock.manage','master/stok.php','📦 Persediaan / Stok'],
            ['categories.manage','master/kategori.php','🗂️ Kategori'],
            ['reports.view','laporan/penjualan.php','📊 Laporan'],
            ['expenses.manage','laporan/pengeluaran.php','💸 Pengeluaran'],
            ['settings.manage','master/pengaturan.php','⚙️ Pengaturan'],
            ['users.manage','master/pengguna.php','👤 Pengguna'],
            ['activity.view','master/aktivitas.php','🛡️ Aktivitas']
        ];
        foreach ($nav as $n):
            if (has_permission($n[0])):
        ?>
            <a class="<?=($currentPath === $basePath.'/'.ltrim($n[1],'/') ? 'active' : '')?>" href="<?=BASE_URL?>/<?=$n[1]?>" title="<?=e(strip_tags($n[2]))?>"><?=$n[2]?></a>
        <?php endif; endforeach; ?>
    </nav>

    <div class="side-bottom">
        <div class="userbox">
            <b><?=e($user['name'] ?? '')?></b>
            <small><?=e(['admin'=>'ADMINISTRATOR','manager'=>'MANAGER','kasir'=>'KASIR','produksi'=>'PRODUKSI'][$user['role'] ?? ''] ?? strtoupper($user['role'] ?? ''))?></small>
        </div>
        <a href="<?=BASE_URL?>/master/profil.php" title="Profil Saya">👤 Profil Saya</a>
        <a href="<?=BASE_URL?>/auth/logout.php" title="Keluar">↪ Keluar</a>
    </div>
</aside>

<main class="main">
    <header class="topbar">
        <button class="menu-btn" type="button" aria-label="Sembunyikan sidebar" title="Sembunyikan / tampilkan sidebar" onclick="window.POSApp && POSApp.toggleSidebar()"><span class="menu-icon">☰</span></button>
        <div class="topbar-title">
            <strong><?=e($title ?? APP_NAME)?></strong>
            <span><?=date('l, d F Y', time())?></span>
        </div>
        <div class="topbar-right">
            <span class="system-status"><span class="online-dot"></span><span>Online</span></span>
            <span class="topbar-time"><?=date('H:i')?> WIB</span>
        </div>
    </header>

    <div class="content">
        <?php foreach (flashes() as $f): ?>
            <div class="alert <?=e($f[0])?>"><?=e($f[1])?></div>
        <?php endforeach; ?>
