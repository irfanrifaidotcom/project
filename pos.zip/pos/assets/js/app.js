(function () {
    'use strict';

    const body = document.body;
    const STORAGE_KEY = 'pos_sidebar_collapsed';

    function isMobile() {
        return window.matchMedia('(max-width: 760px)').matches;
    }

    function applySidebarState() {
        const collapsed = localStorage.getItem(STORAGE_KEY) === '1';
        if (isMobile()) {
            body.classList.remove('sidebar-collapsed');
        } else {
            body.classList.toggle('sidebar-collapsed', collapsed);
        }
        body.classList.remove('sidebar-open');
    }

    window.POSApp = {
        toggleSidebar: function () {
            if (isMobile()) {
                body.classList.toggle('sidebar-open');
                return;
            }
            const collapsed = !body.classList.contains('sidebar-collapsed');
            body.classList.toggle('sidebar-collapsed', collapsed);
            localStorage.setItem(STORAGE_KEY, collapsed ? '1' : '0');
        },
        closeSidebar: function () {
            body.classList.remove('sidebar-open');
        },
        filterTable: function(input, tableId) {
            const q = (input.value || '').toLowerCase().trim();
            const table = document.getElementById(tableId);
            if (!table) return;
            table.querySelectorAll('tbody tr').forEach(function(row){
                row.style.display = !q || row.innerText.toLowerCase().includes(q) ? '' : 'none';
            });
        }
    };

    applySidebarState();
    window.addEventListener('resize', applySidebarState);

    document.querySelectorAll('.side-overlay').forEach(function (el) {
        el.addEventListener('click', POSApp.closeSidebar);
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') POSApp.closeSidebar();
    });

    document.querySelectorAll('.alert').forEach(function (alert) {
        setTimeout(function () {
            alert.classList.add('alert-hide');
            setTimeout(function () { alert.remove(); }, 220);
        }, 4500);
    });
})();
