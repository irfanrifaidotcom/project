/* POS Percetakan - QZ Tray / ESC-POS integration */
(function(){
  'use strict';
  const DEFAULT_PRINTER = 'Struk';
  const BASE = window.POS_BASE_URL || '/pos';
  const esc = String.fromCharCode;
  const printerName = window.POS_PRINTER_NAME || DEFAULT_PRINTER;
  let connecting = null;

  function ensureQz(){
    if(typeof qz === 'undefined') throw new Error('QZ Tray JavaScript belum tersedia. Salin qz-tray.js ke assets/js/ atau gunakan koneksi internet.');
    return qz;
  }
  function connect(){
    ensureQz();
    if(qz.websocket.isActive()) return Promise.resolve();
    if(connecting) return connecting;
    connecting = qz.websocket.connect({retries:3, delay:1}).finally(()=>{connecting=null;});
    return connecting;
  }
  function padRight(v,n){v=String(v??''); return v.length>=n?v.slice(0,n):v+' '.repeat(n-v.length);}
  function padLeft(v,n){v=String(v??''); return v.length>=n?v.slice(-n):' '.repeat(n-v.length)+v;}
  function line(n=48){return '-'.repeat(n)+'\n';}
  function wrap(text,width){
    text=String(text??'').replace(/\r/g,'');
    const out=[];
    text.split('\n').forEach(part=>{
      if(!part){out.push('');return;}
      while(part.length>width){
        let cut=part.lastIndexOf(' ',width); if(cut<1)cut=width;
        out.push(part.slice(0,cut)); part=part.slice(cut).trimStart();
      }
      out.push(part);
    });
    return out;
  }
  function money(n){return 'Rp '+Number(n||0).toLocaleString('id-ID');}
  function buildReceipt(s){
    const W=48;
    let d='';
    d+=esc(27)+'@';
    d+=esc(27)+'t'+esc(19); // Epson Windows-1252-ish code page
    d+=esc(27)+'a'+esc(1); // center
    d+=esc(27)+'E'+esc(1)+String(s.store_name||'POS PERCETAKAN')+'\n'+esc(27)+'E'+esc(0);
    wrap(s.store_address||'',W).forEach(x=>{d+=x+'\n';});
    if(s.store_phone)d+=String(s.store_phone)+'\n';
    d+='\n'+line(W);
    d+=esc(27)+'a'+esc(0);
    const info=[['No',s.invoice_no],['Tgl',new Date(s.created_at.replace(' ','T')).toLocaleString('id-ID')],['Kasir',s.cashier||'-'],['Pelanggan',s.customer||'Pelanggan Umum']];
    info.forEach(r=>{d+=padRight(r[0],10)+String(r[1]||'')+'\n';});
    d+=line(W);
    (s.items||[]).forEach(i=>{
      wrap(i.item_name,W).forEach(x=>{d+=x+'\n';});
      const left=(Number(i.qty).toLocaleString('id-ID')+' x '+money(i.price));
      d+=padRight(left,W-15)+padLeft(money(i.total),15)+'\n';
    });
    d+=line(W);
    d+=padRight('Subtotal',W-15)+padLeft(money(s.subtotal),15)+'\n';
    d+=padRight('Diskon',W-15)+padLeft(money(s.discount),15)+'\n';
    d+=esc(27)+'E'+esc(1)+padRight('TOTAL',W-15)+padLeft(money(s.grand_total),15)+'\n'+esc(27)+'E'+esc(0);
    d+=line(W);
    d+=padRight('Terbayar',W-15)+padLeft(money(s.paid),15)+'\n';
    d+=padRight('Sisa',W-15)+padLeft(money(Math.max(0,s.grand_total-s.paid)),15)+'\n';
    d+=padRight('Kembali',W-15)+padLeft(money(s.change_amount),15)+'\n';
    if((s.payments||[]).length){d+=line(W)+'Pembayaran\n';s.payments.forEach(p=>d+=padRight(p.method,W-15)+padLeft(money(p.amount),15)+'\n');}
    d+='\n'+esc(27)+'a'+esc(1);
    wrap(s.footer||'Terima kasih.',W).forEach(x=>{d+=x+'\n';});
    d+='\n\n\n';
    d+=esc(29)+'V'+esc(1); // cut
    return d;
  }
  async function printSale(saleId){
    const z=ensureQz();
    const r=await fetch(BASE+'/api/receipt_data.php?id='+encodeURIComponent(saleId),{headers:{Accept:'application/json'}});
    const d=await r.json(); if(!d.ok) throw new Error(d.message||'Data struk tidak tersedia.');
    await connect();
    const printer=await z.printers.find(printerName);
    if(!printer) throw new Error('Printer "'+printerName+'" tidak ditemukan. Pastikan nama printer Windows adalah "'+printerName+'" dan QZ Tray sedang berjalan.');
    const cfg=z.configs.create(printer,{encoding:'Cp1252',jobName:'Struk '+d.sale.invoice_no,spool:{end:'\n',size:1}});
    await z.print(cfg,[{type:'raw',format:'command',flavor:'plain',data:buildReceipt(d.sale)}]);
    return d.sale;
  }
  async function testPrint(){
    const z=ensureQz(); await connect();
    const printer=await z.printers.find(printerName);
    if(!printer) throw new Error('Printer "'+printerName+'" tidak ditemukan.');
    const cfg=z.configs.create(printer,{encoding:'Cp1252',jobName:'Test Struk POS',spool:{end:'\n',size:1}});
    const data=esc(27)+'@'+esc(27)+'a'+esc(1)+esc(27)+'E'+esc(1)+'TEST PRINT\n'+esc(27)+'E'+esc(0)+'Struk - Epson TM-T82X-II\n'+new Date().toLocaleString('id-ID')+'\n\n'+line(48)+'Printer siap digunakan.\n\n\n'+esc(29)+'V'+esc(1);
    await z.print(cfg,[{type:'raw',format:'command',flavor:'plain',data}]);
  }
  window.POSPrinter={connect,printSale,testPrint,printerName,buildReceipt};
})();
