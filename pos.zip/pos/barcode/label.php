<?php
$title='Cetak Label Barcode'; require_once __DIR__.'/../includes/header.php';require_permission('barcode.manage');
$id=(int)($_GET['id']??0);$q=db()->prepare('SELECT * FROM products WHERE id=?');$q->execute([$id]);$p=$q->fetch();if(!$p){flash('danger','Produk tidak ditemukan.');redirect('/master/produk.php');}
?>
<div class="card label-page"><div class="toolbar no-print"><div><b>Label Barcode 1D</b><div class="muted">Gunakan printer label atau printer thermal. Barcode dibuat dengan CODE128.</div></div><button class="btn" onclick="window.print()">🖨️ Cetak</button></div>
<div class="barcode-label"><div class="label-name"><?=e($p['name'])?></div><svg id="barcode"></svg><div class="label-price"><?=rupiah($p['price'])?></div><div class="label-code"><?=e($p['barcode'])?></div></div></div>
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"></script><script>JsBarcode('#barcode','<?=e($p['barcode'])?>',{format:'CODE128',displayValue:false,height:58,width:2,margin:0});</script>
<?php require __DIR__.'/../includes/footer.php'; ?>
