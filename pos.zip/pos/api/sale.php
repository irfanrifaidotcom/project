<?php
require_once __DIR__.'/../config/config.php';
require_login();
if($_SERVER['REQUEST_METHOD']!=='POST') redirect('/transaksi/penjualan.php');
csrf_check();
$isJson=str_contains(strtolower($_SERVER['HTTP_ACCEPT']??''),'application/json') || (($_POST['response']??'')==='json');
$user=current_user(); $userId=(int)($user['id']??0); $items=json_decode($_POST['items']??'[]',true);
if(!is_array($items)||!count($items)){if($isJson){http_response_code(422);header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>false,'message'=>'Keranjang kosong.']);exit;}flash('danger','Keranjang kosong.');redirect('/transaksi/penjualan.php');}
$pdo=db(); $pdo->beginTransaction();
try{
 $subtotal=0; $clean=[];
 $get=$pdo->prepare('SELECT id,name,unit,price,item_type,stock FROM products WHERE id=? AND active=1 FOR UPDATE');
 foreach($items as $i){
  $get->execute([(int)($i['id']??0)]); $p=$get->fetch(); if(!$p)continue;
  $qty=max(.01,(float)($i['qty']??1));
  if($p['item_type']==='PRODUCT' && (float)$p['stock'] < $qty) throw new RuntimeException('Stok '.$p['name'].' tidak cukup. Tersedia: '.rtrim(rtrim(number_format((float)$p['stock'],2,'.',''),'0'),'.').' '.$p['unit'].'.');
  $tot=$qty*(float)$p['price']; $subtotal+=$tot; $clean[]=['id'=>$p['id'],'name'=>$p['name'],'qty'=>$qty,'price'=>$p['price'],'total'=>$tot,'item_type'=>$p['item_type'],'stock'=>$p['stock'],'unit'=>$p['unit']];
 }
 if(!$clean)throw new RuntimeException('Tidak ada produk valid.');
 $discount=max(0,(float)($_POST['discount']??0)); $grand=max(0,$subtotal-$discount); $paid=max(0,(float)($_POST['paid']??0)); $change=$paid>$grand?$paid-$grand:0; $invoice=invoice_no();
 $customerId=(int)($_POST['customer_id']??0)?:null; $customer=null;
 if($customerId){$q=$pdo->prepare('SELECT name FROM customers WHERE id=?');$q->execute([$customerId]);$customer=$q->fetchColumn()?:null;}
 $st=$pdo->prepare('INSERT INTO sales(invoice_no,user_id,customer_id,customer_name,order_type,job_description,status,due_date,subtotal,discount,grand_total,paid,change_amount,payment_method) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
 $st->execute([$invoice,$userId,$customerId,$customer,$_POST['order_type']??'Kasir',trim($_POST['job_description']??'')?:null,'BARU',$_POST['due_date']??null,$subtotal,$discount,$grand,$paid,$change,$_POST['payment_method']??'CASH']);
 $sid=(int)$pdo->lastInsertId();
 $ins=$pdo->prepare('INSERT INTO sale_items(sale_id,product_id,item_name,qty,price,total) VALUES(?,?,?,?,?,?)');
 $move=$pdo->prepare("INSERT INTO stock_movements(product_id,movement_type,qty,stock_before,stock_after,reference_type,reference_id,notes,user_id) VALUES(?,?,?,?,?,?,?,?,?)");
 $updStock=$pdo->prepare('UPDATE products SET stock=stock-? WHERE id=?');
 foreach($clean as $x){
  $ins->execute([$sid,$x['id'],$x['name'],$x['qty'],$x['price'],$x['total']]);
  if($x['item_type']==='PRODUCT'){$before=(float)$x['stock'];$after=$before-$x['qty'];$updStock->execute([$x['qty'],$x['id']]);$move->execute([$x['id'],'OUT',$x['qty'],$before,$after,'SALE',$sid,'Penjualan '.$invoice,$userId]);}
 }
 if($paid>0){$p=$pdo->prepare('INSERT INTO payments(sale_id,payment_no,amount,method,user_id) VALUES(?,?,?,?,?)');$p->execute([$sid,'PAY-'.date('YmdHis').random_int(10,99),$paid,$_POST['payment_method']??'CASH',$userId]);}
 $pdo->commit();
 if($isJson){header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>true,'sale_id'=>$sid,'invoice_no'=>$invoice]);exit;}
 redirect('/print/receipt.php?id='.$sid);
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();if($isJson){http_response_code(500);header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>false,'message'=>'Transaksi gagal: '.$e->getMessage()]);exit;}flash('danger','Transaksi gagal: '.$e->getMessage());redirect('/transaksi/penjualan.php');}
