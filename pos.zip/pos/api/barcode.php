<?php
require_once __DIR__.'/../config/config.php';require_permission('barcode.manage');
require_login();
header('Content-Type: application/json; charset=utf-8');
$barcode=trim($_GET['barcode']??'');
if($barcode===''){echo json_encode(['ok'=>false,'message'=>'Barcode kosong']);exit;}
$q=db()->prepare("SELECT p.id,p.code,p.barcode,p.name,p.unit,p.price,p.active,c.name AS category FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.active=1 AND (p.barcode=? OR p.code=?) LIMIT 1");
$q->execute([$barcode,$barcode]);
$p=$q->fetch();
if(!$p){echo json_encode(['ok'=>false,'message'=>'Produk dengan barcode tersebut tidak ditemukan.']);exit;}
echo json_encode(['ok'=>true,'product'=>$p],JSON_UNESCAPED_UNICODE);
