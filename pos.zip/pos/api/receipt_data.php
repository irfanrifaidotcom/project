<?php
require_once __DIR__.'/../config/config.php';
require_permission('sales.view');
header('Content-Type: application/json; charset=utf-8');
$id=(int)($_GET['id']??0);
if(!$id){http_response_code(422);echo json_encode(['ok'=>false,'message'=>'ID transaksi tidak valid.']);exit;}
$pdo=db();
$q=$pdo->prepare("SELECT s.*,COALESCE(c.name,s.customer_name,'Pelanggan Umum') customer,u.name cashier FROM sales s LEFT JOIN customers c ON c.id=s.customer_id LEFT JOIN users u ON u.id=s.user_id WHERE s.id=?");
$q->execute([$id]);$sale=$q->fetch();
if(!$sale){http_response_code(404);echo json_encode(['ok'=>false,'message'=>'Transaksi tidak ditemukan.']);exit;}
$q=$pdo->prepare('SELECT item_name,qty,price,total FROM sale_items WHERE sale_id=? ORDER BY id');$q->execute([$id]);$items=$q->fetchAll();
$q=$pdo->prepare('SELECT method,amount FROM payments WHERE sale_id=? ORDER BY id');$q->execute([$id]);$payments=$q->fetchAll();
echo json_encode(['ok'=>true,'sale'=>[
 'invoice_no'=>$sale['invoice_no'],'created_at'=>$sale['created_at'],'cashier'=>$sale['cashier']??'-','customer'=>$sale['customer']??'Pelanggan Umum','subtotal'=>(float)$sale['subtotal'],'discount'=>(float)$sale['discount'],'grand_total'=>(float)$sale['grand_total'],'paid'=>(float)$sale['paid'],'change_amount'=>(float)$sale['change_amount'],'footer'=>setting('receipt_footer'),'store_name'=>setting('store_name'),'store_address'=>setting('store_address'),'store_phone'=>setting('store_phone'),'items'=>$items,'payments'=>$payments
]]);
