<?php
$title = 'Dashboard';
$page_css = ['dashboard.css'];
require_once __DIR__ . '/includes/header.php';
$pdo = db();

$today = date('Y-m-d');
$monthStart = date('Y-m-01');

$q = $pdo->prepare("SELECT COUNT(*) transaksi, COALESCE(SUM(grand_total),0) omzet, COALESCE(SUM(paid),0) dibayar FROM sales WHERE DATE(created_at)=? AND status <> 'BATAL'");
$q->execute([$today]);
$todayData = $q->fetch(PDO::FETCH_ASSOC) ?: ['transaksi'=>0,'omzet'=>0,'dibayar'=>0];

$q = $pdo->prepare("SELECT COUNT(*) transaksi, COALESCE(SUM(grand_total),0) omzet FROM sales WHERE created_at >= ? AND status <> 'BATAL'");
$q->execute([$monthStart . ' 00:00:00']);
$monthData = $q->fetch(PDO::FETCH_ASSOC) ?: ['transaksi'=>0,'omzet'=>0];

$pending = (int)$pdo->query("SELECT COUNT(*) FROM sales WHERE status IN ('BARU','DIPROSES','SELESAI')")->fetchColumn();
$ready = (int)$pdo->query("SELECT COUNT(*) FROM sales WHERE status='SELESAI'")->fetchColumn();
$customers = (int)$pdo->query("SELECT COUNT(*) FROM customers")->fetchColumn();
$products = (int)$pdo->query("SELECT COUNT(*) FROM products WHERE active=1")->fetchColumn();
$lowStock=[];
try { $lowStock=$pdo->query("SELECT id,code,name,unit,stock,min_stock FROM products WHERE active=1 AND item_type='PRODUCT' AND stock<=min_stock ORDER BY stock ASC,name LIMIT 8")->fetchAll(PDO::FETCH_ASSOC); } catch(Throwable $e) {}

$recent = $pdo->query("SELECT s.*, COALESCE(c.name, NULLIF(s.customer_name,''), 'Umum') customer FROM sales s LEFT JOIN customers c ON c.id=s.customer_id ORDER BY s.id DESC LIMIT 7")->fetchAll(PDO::FETCH_ASSOC);

$week = $pdo->query("SELECT DATE(created_at) d, COUNT(*) transaksi, COALESCE(SUM(grand_total),0) total FROM sales WHERE status <> 'BATAL' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) GROUP BY DATE(created_at) ORDER BY d")->fetchAll(PDO::FETCH_ASSOC);
$weekMap = [];
foreach ($week as $r) $weekMap[$r['d']] = $r;
$weekLabels = $weekTotals = $weekTransactions = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $weekLabels[] = date('d M', strtotime($d));
    $weekTotals[] = (float)($weekMap[$d]['total'] ?? 0);
    $weekTransactions[] = (int)($weekMap[$d]['transaksi'] ?? 0);
}

$best = [];
try {
    $best = $pdo->query("SELECT p.name, SUM(si.qty) qty, SUM(si.qty * si.price) total FROM sale_items si INNER JOIN products p ON p.id=si.product_id GROUP BY si.product_id,p.name ORDER BY qty DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {}

$greeting = ((int)date('H') < 11) ? 'Selamat pagi' : (((int)date('H') < 15) ? 'Selamat siang' : (((int)date('H') < 19) ? 'Selamat sore' : 'Selamat malam'));
?>

<section class="dashboard-hero">
    <div class="hero-copy">
        <div class="eyebrow"><span class="pulse-dot"></span> Sistem POS aktif</div>
        <h1><?=$greeting?>, <?=e($user['name'] ?? 'Admin')?> 👋</h1>
        <p>Pantau penjualan, pesanan, pelanggan, dan aktivitas toko dari satu dashboard.</p>
        <div class="hero-actions">
            <a class="btn primary" href="<?=BASE_URL?>/transaksi/penjualan.php">＋ Transaksi Baru</a>
            <a class="btn hero-secondary" href="<?=BASE_URL?>/transaksi/pesanan.php">Lihat Pesanan</a>
        </div>
    </div>
    <div class="hero-summary">
        <span>Omzet bulan ini</span>
        <strong><?=rupiah($monthData['omzet'])?></strong>
        <small><?=$monthData['transaksi']?> transaksi tercatat</small>
    </div>
</section>

<section class="dashboard-kpis">
    <div class="kpi-card accent-cyan">
        <div class="kpi-top"><span>Omzet Hari Ini</span><i>Rp</i></div>
        <strong><?=rupiah($todayData['omzet'])?></strong>
        <small><?=$todayData['transaksi']?> transaksi hari ini</small>
        <div class="kpi-progress"><span style="width:<?=min(100, max(4, (int)$todayData['transaksi'] * 10))?>%"></span></div>
    </div>
    <div class="kpi-card accent-green">
        <div class="kpi-top"><span>Pembayaran Masuk</span><i>✓</i></div>
        <strong><?=rupiah($todayData['dibayar'])?></strong>
        <small>Uang diterima hari ini</small>
        <div class="kpi-progress"><span style="width:<?=($todayData['omzet'] > 0 ? min(100, (int)round($todayData['dibayar'] / $todayData['omzet'] * 100)) : 0)?>%"></span></div>
    </div>
    <div class="kpi-card accent-orange">
        <div class="kpi-top"><span>Pesanan Berjalan</span><i>↻</i></div>
        <strong><?=$pending?></strong>
        <small><?=$ready?> pesanan siap diambil</small>
        <div class="kpi-progress"><span style="width:<?=min(100, max(4, $pending * 8))?>%"></span></div>
    </div>
    <div class="kpi-card accent-purple">
        <div class="kpi-top"><span>Pelanggan & Produk</span><i>◈</i></div>
        <strong><?=$customers?> <em>pelanggan</em></strong>
        <small><?=$products?> produk/jasa aktif</small>
        <div class="kpi-progress"><span style="width:65%"></span></div>
    </div>
</section>

<?php if (has_permission('stock.manage')): ?>
<section class="dash-card stock-alert-card">
    <div class="dash-card-head inline"><div><span class="section-kicker">PERSEDIAAN</span><h2>Stok Menipis</h2><p>Produk yang sudah mencapai atau melewati stok minimum</p></div><a class="text-link" href="<?=BASE_URL?>/master/stok.php">Kelola stok →</a></div>
    <?php if(!$lowStock): ?><div class="empty">Semua stok masih aman. 👍</div><?php else: ?><div class="stock-alert-grid"><?php foreach($lowStock as $p): ?><a class="stock-alert-item" href="<?=BASE_URL?>/master/produk.php?edit=<?=$p['id']?>"><span><b><?=e($p['name'])?></b><small><?=e($p['code'])?> · minimum <?=e(rtrim(rtrim(number_format((float)$p['min_stock'],2,'.',''),'0'),'.'))?> <?=e($p['unit'])?></small></span><strong><?=e(rtrim(rtrim(number_format((float)$p['stock'],2,'.',''),'0'),'.'))?> <small><?=e($p['unit'])?></small></strong></a><?php endforeach; ?></div><?php endif; ?>
</section>
<?php endif; ?>

<section class="dashboard-grid dashboard-grid-main">
    <div class="dash-card sales-card">
        <div class="dash-card-head">
            <div><span class="section-kicker">PERFORMA</span><h2>Penjualan 7 Hari</h2><p>Pergerakan omzet dan transaksi terbaru</p></div>
            <span class="period-pill">7 Hari</span>
        </div>
        <div class="chart-wrap"><canvas id="salesChart"></canvas></div>
    </div>

    <div class="dash-card quick-card">
        <div class="dash-card-head"><div><span class="section-kicker">SHORTCUT</span><h2>Aksi Cepat</h2><p>Akses fitur utama dengan cepat</p></div></div>
        <div class="quick-grid">
            <a href="<?=BASE_URL?>/transaksi/penjualan.php" class="quick-item"><span class="quick-symbol cyan">＋</span><span><b>Kasir / Order</b><small>Buat transaksi baru</small></span><strong>›</strong></a>
            <a href="<?=BASE_URL?>/transaksi/pesanan.php" class="quick-item"><span class="quick-symbol orange">▤</span><span><b>Pesanan</b><small>Kelola status pesanan</small></span><strong>›</strong></a>
            <a href="<?=BASE_URL?>/master/produk.php" class="quick-item"><span class="quick-symbol green">▦</span><span><b>Produk</b><small>Produk, jasa & barcode</small></span><strong>›</strong></a>
            <a href="<?=BASE_URL?>/laporan/penjualan.php" class="quick-item"><span class="quick-symbol purple">◫</span><span><b>Laporan</b><small>Analisis penjualan</small></span><strong>›</strong></a>
        </div>
    </div>
</section>

<section class="dashboard-grid dashboard-grid-bottom">
    <div class="dash-card">
        <div class="dash-card-head inline"><div><span class="section-kicker">TRANSAKSI</span><h2>Transaksi Terbaru</h2><p>Aktivitas penjualan terakhir</p></div><a class="text-link" href="<?=BASE_URL?>/transaksi/pesanan.php">Lihat semua →</a></div>
        <div class="table-wrap dashboard-table-wrap">
            <table class="table dashboard-table"><thead><tr><th>Invoice</th><th>Pelanggan</th><th>Status</th><th class="text-right">Total</th></tr></thead><tbody>
            <?php if (!$recent): ?><tr><td colspan="4" class="empty">Belum ada transaksi.</td></tr><?php else: foreach ($recent as $r): ?>
                <?php $statusClass=['BARU'=>'blue','DIPROSES'=>'orange','SELESAI'=>'green','DIAMBIL'=>'green','BATAL'=>'red'][$r['status']]??''; ?>
                <tr><td><a class="receipt-link" href="<?=BASE_URL?>/print/receipt.php?id=<?=$r['id']?>" target="_blank"><?=e($r['invoice_no'])?></a><small><?=date('d/m/Y H:i',strtotime($r['created_at']))?></small></td><td><?=e($r['customer'])?></td><td><span class="badge <?=$statusClass?>"><?=e($r['status'])?></span></td><td class="text-right"><b><?=rupiah($r['grand_total'])?></b></td></tr>
            <?php endforeach; endif; ?>
            </tbody></table>
        </div>
    </div>

    <div class="dash-card best-card">
        <div class="dash-card-head inline"><div><span class="section-kicker">PRODUK</span><h2>Produk Terlaris</h2><p>Berdasarkan jumlah terjual</p></div><a class="text-link" href="<?=BASE_URL?>/master/produk.php">Kelola →</a></div>
        <div class="best-list">
        <?php if (!$best): ?><div class="empty">Belum ada data produk terjual.</div><?php else: foreach ($best as $i => $p): ?>
            <div class="best-item"><span class="best-rank"><?=($i+1)?></span><div class="best-info"><b><?=e($p['name'])?></b><small><?=$p['qty']?> terjual</small></div><strong><?=rupiah($p['total'])?></strong></div>
        <?php endforeach; endif; ?>
        </div>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.5.0/dist/chart.umd.min.js"></script>
<script>
(function(){
    const canvas=document.getElementById('salesChart');
    if(!canvas || typeof Chart==='undefined') return;
    const labels=<?=json_encode($weekLabels)?>;
    const values=<?=json_encode($weekTotals)?>;
    const tx=<?=json_encode($weekTransactions)?>;
    const ctx=canvas.getContext('2d');
    const gradient=ctx.createLinearGradient(0,0,0,280);
    gradient.addColorStop(0,'rgba(24,183,201,.24)');
    gradient.addColorStop(1,'rgba(24,183,201,0)');
    new Chart(ctx,{type:'line',data:{labels,datasets:[{data:values,borderColor:'#18b7c9',backgroundColor:gradient,borderWidth:3,fill:true,tension:.42,pointRadius:4,pointHoverRadius:6,pointBackgroundColor:'#fff',pointBorderWidth:3,pointBorderColor:'#18b7c9'}]},options:{responsive:true,maintainAspectRatio:false,interaction:{intersect:false,mode:'index'},plugins:{legend:{display:false},tooltip:{displayColors:false,backgroundColor:'#172033',padding:12,cornerRadius:10,titleFont:{weight:'700'},callbacks:{label:function(c){return ' Omzet: Rp '+new Intl.NumberFormat('id-ID').format(c.raw)},afterLabel:function(c){return ' Transaksi: '+tx[c.dataIndex]}}}},scales:{x:{grid:{display:false},border:{display:false},ticks:{color:'#8b97a7',font:{size:11}}},y:{beginAtZero:true,grid:{color:'rgba(148,163,184,.13)'},border:{display:false},ticks:{color:'#8b97a7',font:{size:11},maxTicksLimit:5,callback:function(v){return 'Rp '+new Intl.NumberFormat('id-ID',{notation:'compact',maximumFractionDigits:1}).format(v)}}}}}});
})();
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
