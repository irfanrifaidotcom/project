-- Upgrade POS Percetakan v25 -> v26: Persediaan / Stok
USE pos_percetakan;

ALTER TABLE products
    ADD COLUMN item_type ENUM('PRODUCT','SERVICE') NOT NULL DEFAULT 'PRODUCT' AFTER cost_price,
    ADD COLUMN stock DECIMAL(14,2) NOT NULL DEFAULT 0 AFTER item_type,
    ADD COLUMN min_stock DECIMAL(14,2) NOT NULL DEFAULT 0 AFTER stock;

CREATE TABLE IF NOT EXISTS stock_movements (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    movement_type ENUM('INITIAL','IN','OUT','ADJUSTMENT','SALE_REVERSAL') NOT NULL,
    qty DECIMAL(14,2) NOT NULL,
    stock_before DECIMAL(14,2) NOT NULL,
    stock_after DECIMAL(14,2) NOT NULL,
    reference_type VARCHAR(40) NULL,
    reference_id BIGINT NULL,
    notes VARCHAR(255) NULL,
    user_id INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_stock_product (product_id),
    INDEX idx_stock_date (created_at),
    INDEX idx_stock_reference (reference_type,reference_id),
    CONSTRAINT fk_stock_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    CONSTRAINT fk_stock_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO permissions(permission_key,permission_name,module,sort_order)
SELECT 'stock.manage','Mengelola Stok & Persediaan','Persediaan',53
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE permission_key='stock.manage');

INSERT INTO role_permissions(role,permission_id)
SELECT 'admin',id FROM permissions WHERE permission_key='stock.manage'
AND NOT EXISTS (SELECT 1 FROM role_permissions rp WHERE rp.role='admin' AND rp.permission_id=permissions.id);
INSERT INTO role_permissions(role,permission_id)
SELECT 'manager',id FROM permissions WHERE permission_key='stock.manage'
AND NOT EXISTS (SELECT 1 FROM role_permissions rp WHERE rp.role='manager' AND rp.permission_id=permissions.id);
INSERT INTO role_permissions(role,permission_id)
SELECT 'produksi',id FROM permissions WHERE permission_key='stock.manage'
AND NOT EXISTS (SELECT 1 FROM role_permissions rp WHERE rp.role='produksi' AND rp.permission_id=permissions.id);
