-- ============================================================
-- POS PERCETAKAN / COMPUTER SHOP
-- Database final - schema + master data + akun + permission
-- Versi: 15 (single SQL, tanpa file upgrade terpisah)
-- ============================================================

CREATE DATABASE IF NOT EXISTS pos_percetakan CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pos_percetakan;

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS user_activity_logs, user_permissions, role_permissions, permissions,
    stock_movements, sale_items, payments, sales, products, categories, customers, expenses, users, settings;
SET FOREIGN_KEY_CHECKS=1;

-- ------------------------------------------------------------
-- USERS & SYSTEM
-- ------------------------------------------------------------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    role ENUM('admin','manager','kasir','produksi') NOT NULL DEFAULT 'kasir',
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE settings (
    setting_key VARCHAR(60) PRIMARY KEY,
    setting_value TEXT NULL
) ENGINE=InnoDB;

CREATE TABLE permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    permission_key VARCHAR(80) NOT NULL UNIQUE,
    permission_name VARCHAR(120) NOT NULL,
    module VARCHAR(50) NOT NULL,
    sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE role_permissions (
    role ENUM('admin','manager','kasir','produksi') NOT NULL,
    permission_id INT NOT NULL,
    PRIMARY KEY (role, permission_id),
    CONSTRAINT fk_role_permissions_permission
        FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE user_permissions (
    user_id INT NOT NULL,
    permission_id INT NOT NULL,
    allowed TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (user_id, permission_id),
    CONSTRAINT fk_user_permissions_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_user_permissions_permission
        FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE user_activity_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    action VARCHAR(80) NOT NULL,
    description VARCHAR(255) NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(255) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_activity_user (user_id),
    INDEX idx_activity_date (created_at),
    CONSTRAINT fk_activity_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- MASTER DATA
-- ------------------------------------------------------------
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    parent_id INT NULL,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(255) NULL,
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_categories_parent (parent_id),
    INDEX idx_categories_active (active),
    CONSTRAINT fk_categories_parent
        FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(120) NOT NULL,
    phone VARCHAR(40) NULL,
    address TEXT NULL,
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NULL,
    code VARCHAR(50) NOT NULL UNIQUE,
    barcode VARCHAR(80) NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    unit VARCHAR(30) NOT NULL DEFAULT 'pcs',
    price DECIMAL(14,2) NOT NULL DEFAULT 0,
    cost_price DECIMAL(14,2) NOT NULL DEFAULT 0,
    item_type ENUM('PRODUCT','SERVICE') NOT NULL DEFAULT 'PRODUCT',
    stock DECIMAL(14,2) NOT NULL DEFAULT 0,
    min_stock DECIMAL(14,2) NOT NULL DEFAULT 0,
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_products_category (category_id),
    INDEX idx_products_active (active),
    CONSTRAINT fk_products_category
        FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- TRANSACTIONS
-- ------------------------------------------------------------
CREATE TABLE sales (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    invoice_no VARCHAR(40) NOT NULL UNIQUE,
    user_id INT NULL,
    customer_id INT NULL,
    customer_name VARCHAR(120) NULL,
    order_type VARCHAR(40) NOT NULL DEFAULT 'Kasir',
    job_description TEXT NULL,
    status ENUM('BARU','DIPROSES','SELESAI','DIAMBIL','BATAL') NOT NULL DEFAULT 'BARU',
    due_date DATE NULL,
    subtotal DECIMAL(14,2) NOT NULL DEFAULT 0,
    discount DECIMAL(14,2) NOT NULL DEFAULT 0,
    grand_total DECIMAL(14,2) NOT NULL DEFAULT 0,
    paid DECIMAL(14,2) NOT NULL DEFAULT 0,
    change_amount DECIMAL(14,2) NOT NULL DEFAULT 0,
    payment_method VARCHAR(30) NOT NULL DEFAULT 'CASH',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_sales_date (created_at),
    INDEX idx_sales_status (status),
    INDEX idx_sales_customer (customer_id),
    CONSTRAINT fk_sales_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_sales_customer
        FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE sale_items (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    sale_id BIGINT NOT NULL,
    product_id INT NULL,
    item_name VARCHAR(150) NOT NULL,
    description VARCHAR(255) NULL,
    qty DECIMAL(12,2) NOT NULL,
    price DECIMAL(14,2) NOT NULL,
    total DECIMAL(14,2) NOT NULL,
    INDEX idx_sale_items_sale (sale_id),
    INDEX idx_sale_items_product (product_id),
    CONSTRAINT fk_sale_items_sale
        FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
    CONSTRAINT fk_sale_items_product
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
 ) ENGINE=InnoDB;

CREATE TABLE stock_movements (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    movement_type ENUM('INITIAL','IN','OUT','ADJUSTMENT','SALE_REVERSAL') NOT NULL,
    qty DECIMAL(14,2) NOT NULL,
    stock_before DECIMAL(14,2) NOT NULL,
    stock_after DECIMAL(14,2) NOT NULL,
    reference_type VARCHAR(40) NULL,
    reference_id BIGINT NULL,
    notes VARCHAR(255) NULL,
    user_id INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_stock_product (product_id),
    INDEX idx_stock_date (created_at),
    INDEX idx_stock_reference (reference_type,reference_id),
    CONSTRAINT fk_stock_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    CONSTRAINT fk_stock_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE payments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    sale_id BIGINT NOT NULL,
    payment_no VARCHAR(40) NOT NULL UNIQUE,
    amount DECIMAL(14,2) NOT NULL,
    method VARCHAR(30) NOT NULL DEFAULT 'CASH',
    notes VARCHAR(255) NULL,
    paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    user_id INT NULL,
    INDEX idx_payments_sale (sale_id),
    CONSTRAINT fk_payments_sale
        FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
    CONSTRAINT fk_payments_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE expenses (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    expense_date DATE NOT NULL,
    category VARCHAR(80) NOT NULL,
    description VARCHAR(255) NOT NULL,
    amount DECIMAL(14,2) NOT NULL,
    user_id INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_expenses_date (expense_date),
    CONSTRAINT fk_expenses_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- AKUN DEFAULT
-- Password default: admin
-- ------------------------------------------------------------
INSERT INTO users (username,password,name,role,active) VALUES
('admin','$2y$12$S628KGH5a3IOVBzekmHGAOriXgd0O7H1euvnth4GPn2hxYdRRZx7m','Administrator','admin',1);

-- ------------------------------------------------------------
-- PERMISSIONS
-- ------------------------------------------------------------
INSERT INTO permissions (permission_key,permission_name,module,sort_order) VALUES
('dashboard.view','Melihat Dashboard','Dashboard',10),
('sales.create','Membuat Transaksi / Kasir','Transaksi',20),
('sales.view','Melihat Transaksi','Transaksi',21),
('orders.manage','Mengelola Pesanan & Status Produksi','Pesanan',30),
('customers.manage','Mengelola Pelanggan','Pelanggan',40),
('products.manage','Mengelola Produk & Jasa','Master',50),
('stock.manage','Mengelola Stok & Persediaan','Persediaan',53),
('categories.manage','Mengelola Kategori','Master',51),
('barcode.manage','Membuat & Mencetak Barcode','Master',52),
('reports.view','Melihat Laporan','Laporan',60),
('expenses.manage','Mengelola Pengeluaran','Laporan',61),
('settings.manage','Mengelola Pengaturan Toko','Sistem',70),
('users.manage','Mengelola Pengguna & Hak Akses','Sistem',71),
('activity.view','Melihat Log Aktivitas','Sistem',72);

INSERT INTO role_permissions(role,permission_id)
SELECT 'admin',id FROM permissions;

INSERT INTO role_permissions(role,permission_id)
SELECT 'manager',id FROM permissions
WHERE permission_key IN (
'dashboard.view','sales.create','sales.view','orders.manage','customers.manage',
'products.manage','categories.manage','barcode.manage','stock.manage','reports.view','expenses.manage','activity.view'
);

INSERT INTO role_permissions(role,permission_id)
SELECT 'kasir',id FROM permissions
WHERE permission_key IN (
'dashboard.view','sales.create','sales.view','orders.manage','customers.manage','barcode.manage'
);

INSERT INTO role_permissions(role,permission_id)
SELECT 'produksi',id FROM permissions
WHERE permission_key IN (
'dashboard.view','orders.manage','customers.manage','sales.view','stock.manage'
);

-- ------------------------------------------------------------
-- KATEGORI BERTINGKAT
-- ------------------------------------------------------------
INSERT INTO categories (parent_id,name,description,active) VALUES
(NULL,'Komputer','Komputer, komponen dan aksesoris komputer',1),
(NULL,'Printer','Printer, tinta, toner dan sparepart printer',1),
(NULL,'Jaringan','Perangkat jaringan, koneksi dan kabel',1),
(NULL,'Percetakan','Jasa dan kebutuhan percetakan',1),
(NULL,'ATK','Alat tulis dan kebutuhan kantor/sekolah',1);

SET @komputer = (SELECT id FROM categories WHERE parent_id IS NULL AND name='Komputer' LIMIT 1);
SET @printer = (SELECT id FROM categories WHERE parent_id IS NULL AND name='Printer' LIMIT 1);
SET @jaringan = (SELECT id FROM categories WHERE parent_id IS NULL AND name='Jaringan' LIMIT 1);
SET @percetakan = (SELECT id FROM categories WHERE parent_id IS NULL AND name='Percetakan' LIMIT 1);
SET @atk = (SELECT id FROM categories WHERE parent_id IS NULL AND name='ATK' LIMIT 1);

INSERT INTO categories (parent_id,name,description,active) VALUES
(@komputer,'Processor','CPU desktop',1),
(@komputer,'Motherboard','Mainboard komputer',1),
(@komputer,'RAM','Memory komputer',1),
(@komputer,'SSD','Solid State Drive',1),
(@komputer,'Harddisk','Harddisk SATA',1),
(@komputer,'VGA','Kartu grafis',1),
(@komputer,'Power Supply','Power supply desktop',1),
(@komputer,'Casing','Casing komputer',1),
(@komputer,'Cooling','Fan dan pendingin komputer',1),
(@komputer,'Keyboard & Mouse','Perangkat input',1),
(@komputer,'Monitor','Monitor komputer',1),
(@komputer,'Aksesoris Komputer','Aksesoris pendukung komputer',1),
(@printer,'Printer','Printer inkjet dan laser',1),
(@printer,'Tinta','Tinta printer',1),
(@printer,'Toner','Toner laser printer',1),
(@printer,'Cartridge','Cartridge printer',1),
(@printer,'Sparepart Printer','Suku cadang printer',1),
(@jaringan,'Router','Router jaringan',1),
(@jaringan,'Switch','Switch jaringan',1),
(@jaringan,'Access Point','Access point WiFi',1),
(@jaringan,'Kabel LAN','Kabel UTP/LAN',1),
(@jaringan,'Connector RJ45','Konektor jaringan',1),
(@percetakan,'Print','Jasa print dokumen',1),
(@percetakan,'Fotocopy','Jasa fotocopy',1),
(@percetakan,'Banner','Cetak banner',1),
(@percetakan,'Stiker','Cetak stiker',1),
(@percetakan,'Jilid','Jasa jilid',1),
(@percetakan,'Laminating','Jasa laminating',1),
(@percetakan,'Cetak Foto','Cetak foto',1),
(@atk,'Kertas','Kertas print dan fotocopy',1),
(@atk,'Alat Tulis','Pulpen, pensil dan alat tulis',1),
(@atk,'Amplop','Amplop surat',1),
(@atk,'Map','Map dokumen',1);

-- ------------------------------------------------------------
-- PELANGGAN DEFAULT
-- ------------------------------------------------------------
INSERT INTO customers(code,name,phone,address,notes) VALUES
('UMUM','Pelanggan Umum','','','Pelanggan umum / walk-in');

-- ------------------------------------------------------------
-- PRODUK / JASA
-- Harga adalah data awal/seed dan dapat diubah dari menu Produk.
-- ------------------------------------------------------------
SET @processor = (SELECT id FROM categories WHERE parent_id=@komputer AND name='Processor');
SET @motherboard = (SELECT id FROM categories WHERE parent_id=@komputer AND name='Motherboard');
SET @ram = (SELECT id FROM categories WHERE parent_id=@komputer AND name='RAM');
SET @ssd = (SELECT id FROM categories WHERE parent_id=@komputer AND name='SSD');
SET @hdd = (SELECT id FROM categories WHERE parent_id=@komputer AND name='Harddisk');
SET @vga = (SELECT id FROM categories WHERE parent_id=@komputer AND name='VGA');
SET @psu = (SELECT id FROM categories WHERE parent_id=@komputer AND name='Power Supply');
SET @casing = (SELECT id FROM categories WHERE parent_id=@komputer AND name='Casing');
SET @cooling = (SELECT id FROM categories WHERE parent_id=@komputer AND name='Cooling');
SET @keyboard = (SELECT id FROM categories WHERE parent_id=@komputer AND name='Keyboard & Mouse');
SET @monitor = (SELECT id FROM categories WHERE parent_id=@komputer AND name='Monitor');
SET @aksesoris = (SELECT id FROM categories WHERE parent_id=@komputer AND name='Aksesoris Komputer');
SET @pprinter = (SELECT id FROM categories WHERE parent_id=@printer AND name='Printer');
SET @tinta = (SELECT id FROM categories WHERE parent_id=@printer AND name='Tinta');
SET @toner = (SELECT id FROM categories WHERE parent_id=@printer AND name='Toner');
SET @cartridge = (SELECT id FROM categories WHERE parent_id=@printer AND name='Cartridge');
SET @router = (SELECT id FROM categories WHERE parent_id=@jaringan AND name='Router');
SET @switch = (SELECT id FROM categories WHERE parent_id=@jaringan AND name='Switch');
SET @ap = (SELECT id FROM categories WHERE parent_id=@jaringan AND name='Access Point');
SET @lan = (SELECT id FROM categories WHERE parent_id=@jaringan AND name='Kabel LAN');
SET @rj45 = (SELECT id FROM categories WHERE parent_id=@jaringan AND name='Connector RJ45');
SET @print = (SELECT id FROM categories WHERE parent_id=@percetakan AND name='Print');
SET @fotocopy = (SELECT id FROM categories WHERE parent_id=@percetakan AND name='Fotocopy');
SET @banner = (SELECT id FROM categories WHERE parent_id=@percetakan AND name='Banner');
SET @stiker = (SELECT id FROM categories WHERE parent_id=@percetakan AND name='Stiker');
SET @jilid = (SELECT id FROM categories WHERE parent_id=@percetakan AND name='Jilid');
SET @laminating = (SELECT id FROM categories WHERE parent_id=@percetakan AND name='Laminating');
SET @foto = (SELECT id FROM categories WHERE parent_id=@percetakan AND name='Cetak Foto');
SET @kertas = (SELECT id FROM categories WHERE parent_id=@atk AND name='Kertas');
SET @alat_tulis = (SELECT id FROM categories WHERE parent_id=@atk AND name='Alat Tulis');
SET @amplop = (SELECT id FROM categories WHERE parent_id=@atk AND name='Amplop');
SET @map = (SELECT id FROM categories WHERE parent_id=@atk AND name='Map');

INSERT INTO products(category_id,code,barcode,name,unit,price,cost_price,active) VALUES
(@processor,'CPU-I3-12100','899000100001','Intel Core i3-12100','pcs',1450000,1300000,1),
(@processor,'CPU-I5-12400','899000100002','Intel Core i5-12400','pcs',2150000,1950000,1),
(@processor,'CPU-R5-5600','899000100003','AMD Ryzen 5 5600','pcs',1650000,1480000,1),
(@motherboard,'MB-H610M','899000100004','Motherboard H610M DDR4','pcs',1050000,920000,1),
(@motherboard,'MB-B550M','899000100005','Motherboard B550M AM4','pcs',1450000,1280000,1),
(@ram,'RAM-DDR4-8','899000100006','RAM DDR4 8GB 3200MHz','pcs',450000,390000,1),
(@ram,'RAM-DDR4-16','899000100007','RAM DDR4 16GB 3200MHz','pcs',780000,690000,1),
(@ssd,'SSD-SATA-480','899000100008','SSD SATA 480GB','pcs',550000,475000,1),
(@ssd,'SSD-NVME-1TB','899000100009','SSD NVMe 1TB','pcs',1050000,900000,1),
(@hdd,'HDD-1TB','899000100010','Harddisk SATA 1TB','pcs',750000,650000,1),
(@vga,'VGA-GTX1650','899000100011','VGA GTX 1650 4GB','pcs',2500000,2250000,1),
(@vga,'VGA-RTX4060','899000100012','VGA RTX 4060 8GB','pcs',5200000,4750000,1),
(@psu,'PSU-500W','899000100013','Power Supply 500W 80+','pcs',300000,255000,1),
(@psu,'PSU-650W','899000100014','Power Supply 650W 80+ Bronze','pcs',650000,560000,1),
(@casing,'CASE-RGB','899000100015','Casing Gaming RGB','pcs',650000,560000,1),
(@cooling,'FAN-120','899000100016','Fan Casing 120mm','pcs',65000,45000,1),
(@keyboard,'KB-MOUSE-USB','899000100017','Keyboard Mouse USB Combo','set',125000,90000,1),
(@keyboard,'MOUSE-USB','899000100018','Mouse USB Optical','pcs',50000,35000,1),
(@monitor,'MON-22-FHD','899000100019','Monitor 22 Inch Full HD','pcs',1450000,1250000,1),
(@monitor,'MON-24-FHD','899000100020','Monitor 24 Inch Full HD','pcs',1850000,1600000,1),
(@aksesoris,'HDMI-3M','899000100021','Kabel HDMI 3 Meter','pcs',65000,45000,1),
(@aksesoris,'FLASH-64','899000100022','Flashdisk 64GB USB 3.0','pcs',110000,85000,1),
(@aksesoris,'USB-HUB-4P','899000100023','USB Hub 4 Port','pcs',85000,60000,1),
(@pprinter,'PRINTER-INK-A4','899000100024','Printer Ink Tank A4','pcs',1850000,1650000,1),
(@pprinter,'PRINTER-LASER-A4','899000100025','Printer Laser Mono A4','pcs',2350000,2100000,1),
(@tinta,'INK-BLACK','899000100026','Tinta Printer Black','botol',75000,55000,1),
(@tinta,'INK-COLOR','899000100027','Tinta Printer Color','botol',75000,55000,1),
(@toner,'TONER-MONO','899000100028','Toner Laser Mono Compatible','pcs',125000,95000,1),
(@cartridge,'CART-BLACK','899000100029','Cartridge Black Compatible','pcs',150000,115000,1),
(@router,'ROUTER-AC1200','899000100030','Router WiFi AC1200','pcs',425000,350000,1),
(@switch,'SW-8P','899000100031','Switch 8 Port Gigabit','pcs',350000,285000,1),
(@ap,'AP-AC1200','899000100032','Access Point AC1200','pcs',650000,550000,1),
(@lan,'LAN-CAT6-1M','899000100033','Kabel LAN Cat6 1 Meter','pcs',15000,9000,1),
(@lan,'LAN-CAT6-10M','899000100034','Kabel LAN Cat6 10 Meter','pcs',85000,60000,1),
(@rj45,'RJ45-PACK','899000100035','Connector RJ45 Cat6 Pack 100','pack',75000,55000,1),
(@print,'PRINT-A4-BW','899000100036','Print A4 Hitam Putih','lembar',500,300,1),
(@print,'PRINT-A4-COLOR','899000100037','Print A4 Warna','lembar',1500,900,1),
(@print,'PRINT-A3-BW','899000100038','Print A3 Hitam Putih','lembar',1500,900,1),
(@fotocopy,'FC-A4','899000100039','Fotocopy A4','lembar',500,300,1),
(@fotocopy,'FC-A3','899000100040','Fotocopy A3','lembar',1000,600,1),
(@banner,'BANNER','899000100041','Cetak Banner','meter',25000,16000,1),
(@stiker,'STIKER','899000100042','Cetak Stiker','meter',35000,22000,1),
(@jilid,'JILID-SPIRAL','899000100043','Jilid Spiral','buku',10000,5000,1),
(@laminating,'LAM-A4','899000100044','Laminating A4','lembar',5000,2500,1),
(@laminating,'LAM-A3','899000100045','Laminating A3','lembar',8000,4000,1),
(@foto,'FOTO-4R','899000100046','Cetak Foto 4R','lembar',5000,2500,1),
(@foto,'FOTO-10R','899000100047','Cetak Foto 10R','lembar',15000,8000,1),
(@kertas,'HVS-A4-70','899000100048','Kertas HVS A4 70gsm','rim',55000,47000,1),
(@kertas,'HVS-A4-80','899000100049','Kertas HVS A4 80gsm','rim',65000,55000,1),
(@kertas,'HVS-F4-70','899000100050','Kertas HVS F4 70gsm','rim',65000,55000,1),
(@alat_tulis,'PULPEN-BLUE','899000100051','Pulpen Ballpoint Biru','pcs',3500,2000,1),
(@alat_tulis,'PENSIL-2B','899000100052','Pensil 2B','pcs',3000,1800,1),
(@alat_tulis,'PENGHAPUS','899000100053','Penghapus Pensil','pcs',2500,1500,1),
(@amplop,'AMPLOP-COKLAT','899000100054','Amplop Coklat A4','pcs',2500,1500,1),
(@map,'MAP-PLASTIK','899000100055','Map Plastik','pcs',2000,1200,1),
(@map,'MAP-SNEL','899000100056','Map Snelhecter','pcs',3500,2200,1);

-- ------------------------------------------------------------
-- PENGATURAN TOKO
-- ------------------------------------------------------------
INSERT INTO settings(setting_key,setting_value) VALUES
('store_name','Nanda Computer & Printing'),
('store_address','Jl. Arif Rahman Hakim No.76, Karawang Kulon'),
('store_phone','085777179189'),
('store_logo',''),
('receipt_footer','Barang yang dibeli tidak dapat dikembalikan.'),
('receipt_width','80'),
('order_prefix','ORD'),
('currency','Rp');

-- ------------------------------------------------------------
-- END
-- ------------------------------------------------------------

INSERT INTO settings(setting_key,setting_value) VALUES ('receipt_printer','Struk') ON DUPLICATE KEY UPDATE setting_value='Struk';
