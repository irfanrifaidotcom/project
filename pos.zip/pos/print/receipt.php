<?php require_once __DIR__.'/../config/config.php';require_permission('sales.view');require_login();$id=(int)($_GET['id']??0);$q=db()->prepare("SELECT s.*,COALESCE(c.name,s.customer_name,'Pelanggan Umum') customer,u.name cashier FROM sales s LEFT JOIN customers c ON c.id=s.customer_id LEFT JOIN users u ON u.id=s.user_id WHERE s.id=?");$q->execute([$id]);$sale=$q->fetch();if(!$sale)exit('Transaksi tidak ditemukan.');$q=db()->prepare('SELECT * FROM sale_items WHERE sale_id=? ORDER BY id');$q->execute([$id]);$items=$q->fetchAll();$q=db()->prepare('SELECT * FROM payments WHERE sale_id=? ORDER BY id');$q->execute([$id]);$payments=$q->fetchAll();$w=setting('receipt_width','80'); ?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><?php $appCss=__DIR__ . '/../assets/css/app.css'; $cssVer=is_file($appCss)?(string)filemtime($appCss):APP_VERSION; ?><title><?=e($sale['invoice_no'])?></title><link rel="stylesheet" href="<?=BASE_URL?>/assets/css/app.css?v=<?=rawurlencode($cssVer)?>"><style>@page{size:<?=$w?>mm auto;margin:0}*{box-sizing:border-box}html,body{margin:0;padding:0;background:#eee}body{font-family:"Courier New",monospace;font-size:11px}.receipt{width:<?=$w?>mm;max-width:100%;margin:10px auto;background:#fff;padding:3mm}.head{text-align:center}.logo{max-width:32mm;max-height:18mm;object-fit:contain}.shop{font-size:14px;font-weight:bold}.muted{font-size:10px}.line{border-top:1px dashed #000;margin:5px 0}.row{display:flex;justify-content:space-between;gap:5px}.item{margin:4px 0}.item-name{word-break:break-word}.item-sub{display:flex;justify-content:space-between}.total{font-size:13px;font-weight:bold}.footer{text-align:center;margin-top:9px;line-height:1.35}.actions{position:fixed;top:10px;right:10px;display:flex;gap:6px}.btn{padding:8px 12px;border:0;border-radius:6px;background:#18b7c9;color:#fff;cursor:pointer}@media print{body{background:#fff}.receipt{margin:0;width:<?=$w?>mm;padding:2.5mm}.actions{display:none}}</style></head><body><div class="actions"><button class="btn" onclick="window.print()">🖨️ Cetak</button><button class="btn" type="button" onclick="closeReceipt()">Tutup</button></div><div class="receipt"><div class="head"><?php if(setting('store_logo')):?><img class="logo" src="<?=BASE_URL.'/'.e(setting('store_logo'))?>"><br><?php endif;?><div class="shop"><?=e(setting('store_name'))?></div><div><?=nl2br(e(setting('store_address')))?></div><div><?=e(setting('store_phone'))?></div></div><div class="line"></div><div class="row"><span>No</span><span><?=e($sale['invoice_no'])?></span></div><div class="row"><span>Tgl</span><span><?=date('d-m-Y H:i',strtotime($sale['created_at']))?></span></div><div class="row"><span>Kasir</span><span><?=e($sale['cashier']??'-')?></span></div><div class="row"><span>Pelanggan</span><span><?=e($sale['customer'])?></span></div><div class="row"><span>Status</span><span><?=e($sale['status'])?></span></div><div class="line"></div><?php foreach($items as $i):?><div class="item"><div class="item-name"><?=e($i['item_name'])?></div><div class="item-sub"><span><?=rtrim(rtrim(number_format($i['qty'],2,',','.'),'0'),',')?> x <?=rupiah($i['price'])?></span><span><?=rupiah($i['total'])?></span></div></div><?php endforeach;?><div class="line"></div><div class="row"><span>Subtotal</span><span><?=rupiah($sale['subtotal'])?></span></div><div class="row"><span>Diskon</span><span><?=rupiah($sale['discount'])?></span></div><div class="row total"><span>TOTAL</span><span><?=rupiah($sale['grand_total'])?></span></div><div class="line"></div><div class="row"><span>Terbayar</span><span><?=rupiah($sale['paid'])?></span></div><div class="row"><span>Sisa</span><span><?=rupiah(max(0,$sale['grand_total']-$sale['paid']))?></span></div><div class="row"><span>Kembali</span><span><?=rupiah($sale['change_amount'])?></span></div><?php if($payments):?><div class="line"></div><div style="font-size:10px">Pembayaran:<br><?php foreach($payments as $p):?><div class="row"><span><?=e($p['method'])?></span><span><?=rupiah($p['amount'])?></span></div><?php endforeach;?></div><?php endif;?><div class="footer"><?=nl2br(e(setting('receipt_footer')))?><br><br>Terima kasih.</div></div><script>
function closeReceipt(){
    try{ if(window.opener && !window.opener.closed){ window.opener.focus(); } }catch(e){}
    window.close();
    setTimeout(function(){
        if(!window.closed){
            alert('Struk sudah selesai. Silakan tutup tab ini secara manual.');
        }
    },150);
}
let printStarted=false;
function startAutoPrint(){
    if(printStarted) return;
    printStarted=true;
    try{
        if(window.opener && !window.opener.closed){
            window.opener.postMessage({type:'pos-sale-complete'}, window.location.origin);
        }
    }catch(e){}
    setTimeout(function(){
        try{ window.print(); }catch(e){}
    },250);
}
window.addEventListener('load',startAutoPrint);
window.addEventListener('afterprint',function(){
    setTimeout(function(){
        try{ window.close(); }catch(e){}
    },300);
});
</script></body></html>
