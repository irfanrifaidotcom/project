# V11 - Kategori Bertingkat Nyata

Versi ini mengaktifkan kategori bertingkat pada UI, bukan hanya database.

## Fitur
- Kategori utama dan subkategori.
- Tree/hierarki visual pada Master > Kategori.
- Tambah, edit, hapus kategori.
- Pilih kategori induk saat membuat/mengedit kategori.
- Pencegahan kategori menjadi induknya sendiri dan pencegahan circular hierarchy.
- Tidak bisa menghapus kategori yang masih mempunyai subkategori atau masih dipakai produk.
- Status aktif/nonaktif dan deskripsi kategori.
- Pencarian kategori.
- Produk menampilkan kategori bertingkat.
- Import Excel mendukung `kategori_induk` + `kategori` dan membuat struktur bila belum ada.
- Template `assets/template_produk_v11.xlsx`.
- SQL `database/upgrade_v11_kategori_tree.sql` idempotent.
